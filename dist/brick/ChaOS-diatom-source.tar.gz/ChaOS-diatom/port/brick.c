/* TrimUI Brick (TG3040) port.
 *
 * Presentation is raw fbdev with a flip thread; SDL2, plastron's own build,
 * provides audio, joystick input and the monotonic clock.
 *
 * fbdev is not a fallback, it is the device's native display path. Measured
 * 2026-08-24 on firmware 1.1.1: scanout is the Allwinner disp2 engine
 * (/dev/fb0 -> the "disp" platform driver), while /dev/dri/card0 is only the
 * PowerVR render node (pvrsrvkm) with no display capability. The firmware's
 * SDL2 has exactly one real video driver, "mali", whose EGL swap blocks
 * ~30ms - two vblank intervals - regardless of swap interval, which quantized
 * the frame loop to 30fps.
 *
 * FBIOPAN_DISPLAY is itself a blocking vsync'd flip. Measured: a pan issued
 * right after vblank returns in one interval (a tight pan loop sustains
 * 60fps), but one issued mid-interval misses the latch deadline and waits for
 * the vsync after next (~25ms). A self-paced loop always lands mid-interval,
 * so calling pan inline halved the frame rate exactly as the EGL swap did.
 *
 * Hence the flip thread. present() only blits and publishes the page in a
 * latest-wins mailbox, never blocking, which is the seam's contract; the
 * thread pans at the panel's own rate and eats the blocking wait. Flips latch
 * at vblank, so no tearing; three pages mean the page being drawn is never
 * the one on glass or in flight. The frame loop keeps its own absolute clock,
 * exactly as on desktop - no console runs at the panel's rate.
 *
 * This file does not include libretro.h and must never need to.
 */
#include <SDL.h>

#include <fcntl.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>

#include "diatom_port.h"
#include "ladder.h"
#include "port_clock.h"
#include "port_cpufreq.h"
#include "shade.h"

#define AUDIO_RATE 48000
/* Capacity in FRAMES (one frame = two int16 samples). 4096 at 48kHz is ~85ms,
 * with rate control aiming to hold it near half that. Same figure as desktop:
 * nothing about the device argues for a different one yet. */
#define AUDIO_BUFFER_FRAMES 4096
#define AUDIO_FRAME_BYTES   (2 * (int)sizeof(int16_t))

#define FB_PAGES 3

static int                       g_fb_fd = -1;
static uint8_t                  *g_fb;
static size_t                    g_fb_size;
static struct fb_var_screeninfo  g_vinfo;
static struct fb_fix_screeninfo  g_finfo;
static int                       g_pages;      /* usable pages, up to FB_PAGES */
static bool                      g_pan_broken; /* pan failed; draw to front */

/* Flip mailbox. All page-role fields are guarded by g_flip_mx:
 *   g_front    on glass (last pan that completed)
 *   g_inflight being panned right now, -1 if none
 *   g_pending  published by present(), waiting for the thread, -1 if none
 * present() draws into any page holding none of those roles; when all three
 * are taken it steals g_pending back, which is safe precisely because the
 * thread only takes pending under the same lock. Latest wins, nothing waits. */
static pthread_t        g_flip_thread;
static pthread_mutex_t  g_flip_mx = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t   g_flip_cv = PTHREAD_COND_INITIALIZER;
static pthread_cond_t   g_flip_idle = PTHREAD_COND_INITIALIZER;
static int              g_front;
static int              g_inflight = -1;
static int              g_pending  = -1;
static bool             g_flip_stop;
static bool             g_flip_running;

/* Has anything been presented since the last present_stop? A handover only
 * gets to choose what is on glass if it is the one putting it there. */
static bool             g_presented;

/* Pages the launcher may have drawn into since this port last drew them
 * (ChaOS). The launcher renders into the same framebuffer (see
 * diatom_port_present_stop), and a frame only ever redraws its own rect, so
 * at a whole-number scale the margins around the picture kept the launcher's
 * shelf and menus: its ground colour and lines, under and beside the game.
 * Stretch never showed it, as it covers the panel. So the first frame drawn
 * into each page after a handover wipes that page to black first. Per page
 * and when drawn into, not all at once, so the page on glass is never
 * blanked under the viewer. */
static bool             g_page_stale[FB_PAGES];

/* The bezel (ChaOS): an image the size of the panel over every frame. Lent by
 * the host (diatom_port_bezel). Outside the picture it never changes, so it is
 * kept once, already laid over black in the framebuffer's own pixels, and
 * that is what a page is wiped to and what the bar, the disc and a notice put
 * back. Inside the picture it is blended over each frame, in ordinary memory
 * before the rows are copied to the page - the page is never read back, which
 * on this framebuffer costs far more than the blend - and only across the
 * runs of each row where it is not clear (bezel_runs): for a bezel with a
 * clear window the size of the picture, nothing at all. */
static const uint8_t *g_bz;
static uint32_t      *g_bz_bg;      /* the bezel over black: its colour times alpha */
static uint8_t       *g_bz_ia;      /* per pixel, 255 - alpha */
static int           *g_bz_row;     /* per panel row + 1: first run in g_bz_run */
static int           *g_bz_run;     /* x0, x1 pairs, within the picture */
static size_t         g_bz_run_cap;
static bool           g_bz_any;     /* any run at all inside the picture */
static diatom_rect    g_bz_dst;
static bool           g_bz_runs_ok;
static uint32_t      *g_bz_frame;   /* the shaded picture, before it goes to the page */
static size_t         g_bz_frame_cap;

/* What a pixel outside the picture is when nothing is on it. */
#define BG(x, y) (g_bz_bg ? g_bz_bg[(size_t)(y) * g_vinfo.xres + (size_t)(x)] : g_opaque)

static SDL_AudioDeviceID g_audio;
static int               g_pad_fd = -1;  /* "Brick Gamepad": every button */
static bool              g_quit;
static uint32_t          g_buttons;
static bool              g_input_debug;
static bool              g_present_debug;

/* Opaque value for the framebuffer's alpha channel, zero if it has none.
 * The disp2 engine composites the fb layer in PER-PIXEL alpha mode: pixels
 * with a zero alpha byte are invisible, composited over black. Measured the
 * hard way 2026-08-24 - a pipeline that paced and captured perfectly while
 * the panel showed nothing, because capture reads memory and the panel reads
 * alpha. */
static uint32_t g_opaque;

/* Resampling maps, one entry per destination pixel on each axis, rebuilt only
 * when the source size, the destination rect or the filter changes.
 *
 * `w` is the weight of source pixel idx+1, in 1/256 units. Zero means the
 * destination pixel sits wholly inside one source pixel, which is the case for
 * every pixel at an integer factor and for most of them otherwise - so it is
 * the fast path, not an optimization for a rare case. */
typedef struct { int idx; int w; } diatom_tap;
typedef struct { int r, g, b; }    diatom_rgb;

static diatom_tap  *g_colmap, *g_rowmap;
static int          g_map_src_w = -1, g_map_src_h = -1;
static diatom_rect  g_map_dst;
static diatom_filter g_map_filter;
static bool          g_map_valid;

/* Output gain, by ioctl on /dev/snd/controlC0.
 *
 * Written for TrimUI's system, which had no alsa-lib or tinyalsa headers, and
 * forking `tinymix` per keypress means a process spawn in the input path plus a
 * dependency on a binary. So: a raw ioctl on a device node, which is what this
 * port already does for /dev/fb0. The struct layout is vendored from the kernel
 * UAPI rather than depended on, and its SIZE is baked into the request number
 * by _IOWR - validated against the running kernel by a probe (mixprobe) before
 * it was written here (sizeof 1224, read agreed with tinymix to the digit).
 *
 * `digital volume` is 0-63 and **INVERTED**: 0 is loudest, 63 is silence. The
 * driver advertises `dBscale-min=-74.24dB, step=+1.16dB`, i.e. that higher is
 * louder. That metadata is wrong. Proven by diffing the mixer across a
 * volume-up press in the device UI: 37 -> 15 when turned UP.
 *
 * `Headphone Volume` is 0-7 at 6 dB a step and is **INVERTED** too: 0 is
 * loudest, 7 is near silence, and its TLV lies about the direction exactly the
 * way `digital volume`'s does. Nothing on this codec's metadata can be trusted.
 *
 * This comment used to say the opposite - that the control was not a speaker
 * level, and that raising it rerouted output to the headphone JACK and muted
 * the speakers. That was wrong, and it was wrong in the most expensive way
 * available: `HpSpeaker Switch` drives the speaker off the headphone stage, so
 * this control gates everything the device plays. Whoever wrote the note
 * raised it, heard the speaker fall away, and reached for routing to explain
 * an attenuation. Settled by ear on 2026-08-31 with no plug in the jack - at 7
 * the speaker is barely audible, at 0 it is loud. It had sat at 3 since the
 * project began, so every sound Diatom has ever made was 18 dB down.
 */
struct dm_ctl_elem_id {
	unsigned int numid; int iface; unsigned int device, subdevice;
	unsigned char name[44]; unsigned int index;
};
struct dm_aes_iec958 {
	unsigned char status[24], subcode[147], pad, dig_subframe[4];
};
struct dm_ctl_elem_value {
	struct dm_ctl_elem_id id;
	unsigned int indirect: 1;
	union {
		union { long value[128]; long *value_ptr; } integer;
		union { long long value[64]; long long *value_ptr; } integer64;
		union { unsigned int item[128]; unsigned int *item_ptr; } enumerated;
		union { unsigned char data[512]; unsigned char *data_ptr; } bytes;
		struct dm_aes_iec958 iec958;
	} value;
	unsigned char reserved[128];
};
#define DM_CTL_ELEM_READ   _IOWR('U', 0x12, struct dm_ctl_elem_value)
#define DM_CTL_ELEM_WRITE  _IOWR('U', 0x13, struct dm_ctl_elem_value)

#define GAIN_CTL     "digital volume"
#define GAIN_RAW_MAX 63         /* control range; 0 is loudest, 63 silent */
/* The part of that range you can actually hear.
 *
 * The register goes to 63 and stops being useful long before it: measured on
 * the speaker against a room baseline of 33 rms, raw 26 is 173 rms - five times
 * the room, quiet but unmistakably there - and by raw 34 it is 55, which is 1.6
 * times the room and indistinguishable from nothing. Spreading twenty levels
 * across the whole 63 therefore spends more than half the slider below the
 * floor: level 10 of 20 landed on raw 31, about two and a half times the room,
 * which is what "50% and very quiet" is.
 *
 * TortOS's launcher already had this number - the sweep was done there and the
 * constant is GAIN_RAW_USABLE in its src/platform.c. The port carries its own
 * copy of the mapping because it owns the level while a game runs, and only one
 * of the two was corrected. Same measurement, same ceiling, so the bar means
 * the same thing on the shelf and in a game.
 *
 * Those rms figures were taken with HP_CTL already at 0 - the sweep script sets
 * it before measuring - so they describe the chain as it behaves now, and the
 * 18 dB mixer_defaults() restored was never inside them. A note here briefly
 * claimed otherwise; it was inferred instead of read off the script that made
 * the table. The gap was between the SWEEP and gameplay, not inside the sweep,
 * which is why the table looked sane while the device sounded quiet.
 *
 * The weakness is the instrument. Those readings came from a microphone across
 * the room, where raw 26 is 5.2x the room and raw 34 is indistinguishable from
 * it - but a handheld sits at arm's length, and what reads as silence over
 * there is plainly audible in your hands. The floor is therefore set by ear,
 * not by this table.
 *
 * That session had ONE WORKING SPEAKER, unknown at the time. The quiet channel
 * turned out on 2026-09-02 to be a loose connection on the PCB; resoldered, and
 * both now play evenly. So 39 was originally judged against roughly half this
 * device's output - and it stood anyway, re-heard on the repaired hardware the
 * same day across the quiet end, the balance and the general sound. Two
 * independent confirmations now, not one lucky derivation.
 *
 * 39, chosen on the device on 2026-08-31 with a game playing, stepping the
 * register down until Eric called it: raw 37 is barely audible and is where he
 * wanted position 1. 39 is the constant that lands position 1 on 37 in both
 * this ladder and the launcher's, which round differently; 26 put it on 25.
 * Position 20 still lands on raw 0, so maximum is unchanged.
 *
 * The cost is resolution: about 2.3 dB a press rather than 1.5, in exchange for
 * 45 dB of range rather than 30. Worth it - 30 dB down is not quiet in a quiet
 * room, which is the thing a microphone across the room could not tell us. */
#define GAIN_RAW_USABLE 39

/* The jack wants a different window, not the same one moved.
 *
 * Set by ear on 2026-09-02 with a game playing and a plug in, the same method
 * that produced 39. The ceiling first: above raw 8 it is uncomfortable, so 8 is
 * where level 20 belongs. Then the floor, stepping down - 37, 45, 49, 53 and 57
 * were each still too loud to be a minimum, and 61 was called right.
 *
 * So the jack spends 53 register steps where the speaker spends 39, which an
 * offset cannot express: offsetting from the ceiling would put level 1 on 47,
 * and 45 was rejected on the way past. Headphones are far more efficient than
 * this speaker, so the same twenty steps have to cover more ground - 61 dB
 * against 45, about 3.1 dB a step rather than 2.3.
 *
 * The launcher carries the same four numbers in its src/platform.c, for the
 * same reason it carries GAIN_RAW_USABLE: this port owns the level while a game
 * runs and the shelf owns it otherwise, so a level that crosses the socket has
 * to mean the same thing on both sides. Change one, change the other. */
#define SPK_RAW_TOP     0
#define SPK_RAW_BOTTOM  GAIN_RAW_USABLE
#define HP_RAW_TOP      8
#define HP_RAW_BOTTOM   61

#define GAIN_LEVELS  20         /* what the USER moves in: 20 steps of 5% */
#define SPEAKER_CTL  "HpSpeaker Switch"   /* the speaker's only true mute */

/* Set by the launcher over the state plane, never read from hardware here:
 * what the switch is and what it means are the launcher's. */
static bool g_muted;
#define HP_CTL       "Headphone Volume"   /* 0-7, 6 dB a step, INVERTED */
#define HP_CTL_QUIET 7                    /* its quiet end, for the cut */
#define SWAP_CTL     "DAC Swap"           /* 1 crosses left and right */

/* Backlight. This device has no /sys/class/backlight; the panel is driven by
 * the Allwinner disp2 engine, and the firmware's own settings library goes
 * through /dev/disp. These are plain command numbers with an unsigned long[4]
 * argument block rather than _IOWR-encoded requests, so there is no struct size
 * to get wrong - validated against the running kernel by a probe (dispprobe)
 * before it was written here.
 *
 * Not inverted, unlike the mixer: 0 is dark, 255 is full. */
#define DISP_LCD_SET_BRIGHTNESS 0x102
#define DISP_LCD_GET_BRIGHTNESS 0x103

/* Brightness is perceived proportionally, not linearly. Measured 2026-08-26:
 * eight successive halvings of duty were all still visible, so equal *ratios*
 * are what read as equal steps. The 20-step linear ramp this replaces put nine
 * of its twenty steps above raw 128, where consecutive ones cannot be told
 * apart, and left raw 1-12 unreachable at any setting.
 *
 * The rungs are the launcher's own, read off TortOS's brightness keys, with two
 * added below. Matching them is not deference: every value here except the
 * bottom two is one the launcher also has a level for, so a brightness set in a
 * game means the same thing on the other side of the exit instead of snapping
 * to whatever is nearest. The step COUNT is launcher policy and belongs in the
 * protocol eventually; this is the standalone default.
 *
 * The first rung is the panel's measured floor - 0 and 1 are black, and the
 * driver clamps neither. TortOS's own bottom level is raw 1 and is deliberately
 * not copied. This table is also the only clamp there is: no arithmetic here
 * can produce a value off its ends. */
static const unsigned char bright_ladder[] = {
	2, 4, 8, 16, 32, 48, 72, 96, 128, 160, 192, 255
};
#define BRIGHT_LEVELS ((int)(sizeof bright_ladder / sizeof bright_ladder[0]) - 1)

static int g_disp_fd = -1;

static int g_mixer_fd = -1;
static int g_level = -1;        /* the position last read or written; -1 none */
static uint64_t g_osd_until;    /* show the bar until this time */

/* The overlay from diatom_port_overlay: a borrowed pointer, not a copy. See
 * diatom_port.h for the lifetime the host guarantees. */
static const uint8_t *g_ov;
static int            g_ov_w, g_ov_h;
static uint64_t       g_ov_until;
static int      g_osd_level;    /* what the bar shows - volume OR brightness */
static int      g_osd_max = GAIN_LEVELS;   /* out of what: the two differ now */
static int      g_osd_kind;     /* 0 volume, 1 brightness - only the tint differs */
/* Which pages still carry a bar outside the picture.
 *
 * blit only writes inside dst, so in any mode that does not fill the panel the
 * band above the picture is never written again and the bar stays there for
 * good - as two stubs in the pillarbox margins, appearing and disappearing as
 * the pages rotate. Recorded per page because a page is only safe to touch
 * when it is the one being prepared. */
static bool     g_osd_painted[FB_PAGES];

/* Is there a plug in the headphone jack?
 *
 * SW_HEADPHONE_INSERT on the codec's own input node. The state is nowhere else
 * on this device - no ALSA jack control among its seventeen, nothing in sysfs -
 * so EVIOCGSW is the only way to ask, which is why this opens an input device
 * rather than reading a file.
 *
 * Found by capability, not by number. It is /dev/input/event2 today, but that
 * is an enumeration order rather than a promise, and being wrong would mean a
 * ladder calibrated for the wrong output with no sign that anything is off. */
#define BITS_PER_LONG   (8 * (int)sizeof(long))
#define NLONGS(max)     (((max) + BITS_PER_LONG) / BITS_PER_LONG)
#define SW_NLONGS       NLONGS(SW_MAX)
#define BIT_IS_SET(a,b) (((a)[(b) / BITS_PER_LONG] >> ((b) % BITS_PER_LONG)) & 1UL)

static int g_jack_fd = -1;

/* The gamepad and the headphone jack, in one pass, as the Pixel 2's port finds
 * its own, keeping the nodes it wants and closing only the rest: closing an
 * evdev descriptor waits out an RCU grace period in the kernel. */
static void input_scan(void)
{
	unsigned long keys[NLONGS(KEY_MAX)], sw[SW_NLONGS];
	char path[32];
	int i, fd;

	for (i = 0; i < 32; i++) {
		bool kept = true;

		snprintf(path, sizeof path, "/dev/input/event%d", i);
		if ((fd = open(path, O_RDONLY | O_NONBLOCK | O_CLOEXEC)) < 0) continue;
		memset(keys, 0, sizeof keys);
		memset(sw, 0, sizeof sw);
		ioctl(fd, EVIOCGBIT(EV_KEY, sizeof keys), keys);
		ioctl(fd, EVIOCGBIT(EV_SW, sizeof sw), sw);
		if      (g_pad_fd < 0  && BIT_IS_SET(keys, BTN_SOUTH))          g_pad_fd = fd;
		else if (g_jack_fd < 0 && BIT_IS_SET(sw, SW_HEADPHONE_INSERT))  g_jack_fd = fd;
		else kept = false;
		if (!kept) close(fd);
	}
}

static void input_open(void);

static void jack_open(void)
{
	if (g_jack_fd < 0) input_scan();
	if (g_jack_fd < 0)
		fprintf(stderr, "diatom: no headphone jack input node; "
		                "volume will use the speaker ladder\n");
}

static int jack_present(void)
{
	unsigned long bits[SW_NLONGS];

	if (g_jack_fd < 0) return 0;
	memset(bits, 0, sizeof bits);
	if (ioctl(g_jack_fd, EVIOCGSW(sizeof bits), bits) < 0) return 0;
	return BIT_IS_SET(bits, SW_HEADPHONE_INSERT) ? 1 : 0;
}

/* Which window the level maps into. See HP_RAW_TOP above: headphones and the
 * speaker want different ceilings AND different floors, so both ends move. */
/* The top position of the ladder in use: GAIN_LEVELS, or up to GAIN_NIGHT_EXTRA
 * more when the launcher is in night mode. The bottom is the same ladder run
 * at the same step width, computed exactly as TortOS does (device/brick.c
 * vol_bottom), so both sides meet at the same register value. */
#define GAIN_NIGHT_EXTRA 8
static int g_gain_levels = GAIN_LEVELS;

static int gain_top(void)  { return jack_present() ? HP_RAW_TOP    : SPK_RAW_TOP; }
static int gain_bot(void)
{
	int top = gain_top(), bot = jack_present() ? HP_RAW_BOTTOM : SPK_RAW_BOTTOM;
	long b;

	if (g_gain_levels <= GAIN_LEVELS) return bot;
	b = top + ((long)(bot - top) * g_gain_levels + GAIN_LEVELS / 2) / GAIN_LEVELS;
	return b > GAIN_RAW_MAX ? GAIN_RAW_MAX : (int)b;
}

/* Positions to the register and back; the inverted register never leaves this
 * file. The register is the window as it stands, 0 loudest (port/ladder.h). A
 * register left past the window by another program reads as an end of the
 * scale: with a plug in, anything louder than raw 8 was set by something that
 * was not us. */
static int level_to_raw(int lv)
{
	return ladder_window_raw(lv, g_gain_levels, gain_top(), gain_bot());
}
static int raw_to_level(int raw)
{
	return ladder_window_pos(raw, g_gain_levels, gain_top(), gain_bot());
}

static int ctl_io(const char *name, long *val, int write)
{
	struct dm_ctl_elem_value v;

	if (g_mixer_fd < 0) return -1;
	memset(&v, 0, sizeof v);
	v.id.iface = 2;                                 /* SNDRV_CTL_ELEM_IFACE_MIXER */
	snprintf((char *)v.id.name, sizeof v.id.name, "%s", name);
	if (write) {
		v.value.integer.value[0] = *val;
		return ioctl(g_mixer_fd, DM_CTL_ELEM_WRITE, &v);
	}
	if (ioctl(g_mixer_fd, DM_CTL_ELEM_READ, &v) < 0) return -1;
	*val = v.value.integer.value[0];
	return 0;
}

static int gain_io(long *val, int write) { return ctl_io(GAIN_CTL, val, write); }

/* Write a control and complain if it does not land. The launcher had this same
 * write spelled "Headphone", a control this codec does not have; the ioctl
 * matches names exactly and the return was discarded, so it silently did
 * nothing for the life of the project while the source read as though it had
 * worked. Nothing here writes a control without checking again. */
static void ctl_set(const char *name, long val)
{
	if (ctl_io(name, &val, 1) < 0)
		fprintf(stderr, "brick: mixer rejected '%s' = %ld\n", name, val);
}

/* Codec-wide state that the volume level does not own, set once at init.
 *
 * Diatom sets this itself rather than inheriting it from the launcher because
 * it runs standalone as well as under one, and a frontend that is quiet only
 * when started the wrong way is worse than one that is simply quiet.
 * Idempotent, so both doing it costs nothing.
 *
 * HP_CTL: see the header comment above - 0 is the loud end.
 * SWAP_CTL at 1 crosses the channels. The stock hook clears it
 * (runtrimui-original.sh: `tinymix set 1 0`) and so does NextUI; we never did,
 * so left and right have been backwards the whole time. It is enumerated
 * rather than integer, but the value union overlaps and we only ever write
 * item 0, so the integer path reaches it. */
static void mixer_defaults(void)
{
	if (g_mixer_fd < 0) return;
	ctl_set(HP_CTL, 0);
	ctl_set(SWAP_CTL, 0);
}

/* Re-apply if the plug went in or came out since the last write.
 *
 * Without this the level only moves to the right window at the next volume
 * press, so plugging in mid-game leaves the old register in place - which is
 * the exact moment the difference is 9 dB and being worn on your head. One
 * ioctl on an already-open fd, and it writes nothing unless the state moved.
 *
 * The launcher does the same on its side, from plat_input_poll. Whichever
 * process is pumping input owns the level, so the two never write over each
 * other: the launcher stops polling while a game runs, and this stops when the
 * game ends. */
static int g_jack_was = -1;                /* last state written; -1 = never */
static void gain_apply(void);

static void gain_jack_poll(void)
{
	if (jack_present() == g_jack_was || g_level < 0) return;
	gain_apply();
}

static void gain_apply(void)
{
	bool cut = g_level <= 0 || g_muted;
	long v = cut ? GAIN_RAW_MAX : level_to_raw(g_level);
	long quiet = cut ? HP_CTL_QUIET : 0;

	g_jack_was = jack_present();
	if (gain_io(&v, 1) < 0) return;
	ctl_io(HP_CTL, &quiet, 1);

	/* Zero has to cut the path, not just attenuate it. The control advertises
	 * `mute=0`, meaning its minimum is maximum attenuation - about -74 dB -
	 * and not silence. Measured: with an ear against the speaker, level 0 is
	 * still audible, and a mic across the room cannot tell it from the room.
	 * So the speaker switch carries the last step.
	 *
	 * AND NEVER BACK ON WHILE MUTED. This line is where the launcher's mute
	 * used to die: with the switch down and a game muted, one volume press
	 * re-enabled the stage and the sound returned. The cut for level 0 is
	 * still ours; turning it on again is not, while somebody else is
	 * holding it off. */
	v = !cut;
	ctl_io(SPEAKER_CTL, &v, 1);
	/* The switch cuts the speaker only, so with headphones in neither the
	 * mute nor level 0 silenced them until 2026-09-30. They are cut by level
	 * instead: GAIN_CTL and HP_CTL both at their quiet ends, silent by ear
	 * that day. Not "Headphone Switch", tried the same day: with it and
	 * SPEAKER_CTL both off the codec stops taking samples, and the audio
	 * thread waits on it - a game froze switching to a headset until the
	 * mute came off. */
}

static void osd_show(int kind, int level, int max)
{
	/* Feedback lives here too: the launcher owns UI, but it is not drawing
	 * while a game runs, so nothing else can show this. 1.5s from the last
	 * press, so holding a key keeps the bar up. */
	g_osd_kind  = kind;
	g_osd_level = level;
	g_osd_max   = max;
	g_osd_until = diatom_port_now_us() + 1500000ull;
}

/* The panel at a rung, and back as the nearest rung, so a level the launcher
 * left between two reads as the closer one - exact for every level the launcher
 * can set except its black one. */
static void bright_apply(int pos)
{
	unsigned long a[4] = { 0, 0, 0, 0 };

	if (pos < 0)             pos = 0;
	if (pos > BRIGHT_LEVELS) pos = BRIGHT_LEVELS;
	a[1] = bright_ladder[pos];
	ioctl(g_disp_fd, DISP_LCD_SET_BRIGHTNESS, a);
}

static int bright_read(void)
{
	unsigned long a[4] = { 0, 0, 0, 0 };
	int raw;

	if (g_disp_fd < 0) return -1;
	raw = ioctl(g_disp_fd, DISP_LCD_GET_BRIGHTNESS, a);
	if (raw < 0) return -1;
	return ladder_nearest(bright_ladder, BRIGHT_LEVELS + 1, raw);
}

/* The one indicator, matching what the device UI draws so volume reads the same
 * in a game as on the shelf: a scrim across the very top with a 6px bar in it.
 * No glyph, no number - you know which button you just pressed.
 *
 * Drawn straight into the page after the blit and before publish, so it rides
 * the same flip and costs one pass over 12 rows. */
static void draw_gain_bar(uint8_t *base)
{
	const unsigned ro = g_vinfo.red.offset, go = g_vinfo.green.offset;
	const unsigned bo = g_vinfo.blue.offset;
	const int pad = 3, bar = 6;
	const int W = (int)g_vinfo.xres;
	/* The launcher's two, so the bar means the same thing on the shelf and in
	 * a game: UI_OSD_VOLUME and UI_OSD_BRIGHT in TortOS's src/ui.h. This was
	 * one hardcoded off-white for both, which made the in-game bar the only
	 * place the color did not say which key you had pressed. */
	const unsigned tint_r = g_osd_kind ? 255u :  61u;
	const unsigned tint_g = g_osd_kind ? 206u : 214u;
	const unsigned tint_b = g_osd_kind ? 128u : 255u;
	int fill = g_osd_level < 0 || g_osd_max <= 0 ? 0
	         : (W * g_osd_level) / g_osd_max;
	int y, x;

	for (y = 0; y < pad * 2 + bar; y++) {
		uint32_t *row = (uint32_t *)(base + (size_t)y * g_finfo.line_length);
		for (x = 0; x < W; x++) {
			uint32_t p = row[x];
			if (y < pad || y >= pad + bar) {
				/* Scrim: halve what is already there. */
				uint32_t r = ((p >> ro) & 0xff) >> 1;
				uint32_t g = ((p >> go) & 0xff) >> 1;
				uint32_t b = ((p >> bo) & 0xff) >> 1;
				row[x] = (r << ro) | (g << go) | (b << bo) | g_opaque;
			} else if (x < fill) {
				row[x] = ((uint32_t)tint_r << ro) | ((uint32_t)tint_g << go)
				       | ((uint32_t)tint_b << bo) | g_opaque;
			} else {
				row[x] = (60u << ro) | (62u << go) | (72u << bo) | g_opaque;
			}
		}
	}
}

/* Put back what the bar covered, for the part of the band the picture does not
 * reach. Inside dst the blit has already redrawn it this frame; outside dst
 * nothing ever will, which is the whole bug. Black, because that is what the
 * margin around a picture is. */
static void clear_gain_bar(uint8_t *base, diatom_rect dst)
{
	const int pad = 3, bar = 6, band = pad * 2 + bar;
	const int W = (int)g_vinfo.xres;
	int x0 = dst.x > 0 ? dst.x : 0;
	int x1 = dst.x + dst.w < W ? dst.x + dst.w : W;
	int y, x;

	for (y = 0; y < band; y++) {
		uint32_t *row = (uint32_t *)(base + (size_t)y * g_finfo.line_length);
		bool covered = y >= dst.y && y < dst.y + dst.h;

		for (x = 0; x < W; x++) {
			if (covered && x >= x0 && x < x1) continue;   /* the blit's */
			row[x] = BG(x, y);
		}
	}
}

/* The low-battery disc: the launcher's, drawn the launcher's way so it reads
 * the same in a game as on the shelf (TortOS's draw_low_battery_dot):
 * horizontal spans of a disc of radius 9, centered 34 px from the top and
 * right edges. Like the bar it goes into the page after the blit, and when it
 * goes, what it covered outside the picture is put back to black - inside, the
 * blit has already redrawn it. */
#define DOT_R  9
#define DOT_IN 34
static bool g_lowbat, g_lowbat_blink;
static bool g_dot_painted[FB_PAGES];

/* Shown this frame: always when low, the even seconds when blinking. */
static bool dot_visible(void)
{
	return g_lowbat && (!g_lowbat_blink || (diatom_port_now_us() / 1000000u) % 2 == 0);
}

static void dot_page(uint8_t *base, diatom_rect dst, bool draw)
{
	const unsigned ro = g_vinfo.red.offset, go = g_vinfo.green.offset;
	const unsigned bo = g_vinfo.blue.offset;
	const uint32_t red = (224u << ro) | (72u << go) | (72u << bo) | g_opaque;
	const int cx = (int)g_vinfo.xres - DOT_IN, cy = DOT_IN;
	int dy;

	for (dy = -DOT_R; dy <= DOT_R; dy++) {
		const int v = DOT_R * DOT_R - dy * dy, y = cy + dy;
		uint32_t *row = (uint32_t *)(base + (size_t)y * g_finfo.line_length);
		bool covered = y >= dst.y && y < dst.y + dst.h;
		int dx = 0, x;

		/* The launcher's span: sqrt(v) rounded, so the two discs match to the
		 * pixel. The largest dx with (2dx - 1)^2 <= 4v. */
		while ((2 * (dx + 1) - 1) * (2 * (dx + 1) - 1) <= 4 * v) dx++;
		for (x = cx - dx; x <= cx + dx; x++) {
			if (draw)
				row[x] = red;
			else if (!covered || x < dst.x || x >= dst.x + dst.w)
				row[x] = BG(x, y);
		}
	}
}

void diatom_port_low_battery(bool on, bool blink)
{
	g_lowbat = on;
	g_lowbat_blink = blink;
}

/* The picture under the notice, in ordinary memory.
 *
 * Blending needs what is underneath, and reading it back out of the page was
 * the whole cost of a notice: framebuffer memory is slow to READ, and a notice
 * is almost all part-transparent pixels - 25,543 of 28,884 in an achievements
 * notice. Measured 2026-09-30 in Aladdin: 5.85 ms a frame to draw the notice
 * over a 4.14 ms picture, and in Sonic, whose picture costs 6.6 ms, enough to
 * miss frames. So while a notice is up, blit puts the rows it covers here as
 * it draws them, and the blend reads this instead of the page. */
static uint32_t *g_ov_under;
static size_t    g_ov_under_cap;     /* in pixels */
static bool      g_ov_live;          /* drawn this frame: decided once, in present */

static int ov_x0(void) { return ((int)g_vinfo.xres - g_ov_w) / 2; }
static int ov_y0(void) { return (int)g_vinfo.yres - g_ov_h - (int)g_vinfo.yres / 24; }

void diatom_port_shader(diatom_shader kind, const float *params, int nparams)
{
	shade_set(kind, params, nparams);
}

void diatom_port_shade_cost(double *ms, unsigned *frames, int *threads)
{
	shade_cost(ms, frames, threads);
}

void diatom_port_overlay(const uint8_t *bgra, int w, int h, unsigned ms)
{
	if (!bgra || ms == 0 || w <= 0 || h <= 0) {
		g_ov = NULL;
		g_ov_until = 0;
		return;
	}
	/* Refused, not clipped. Half a notice off the edge of the panel looks
	 * deliberate and is not. */
	if (w > (int)g_vinfo.xres || h > (int)g_vinfo.yres) {
		diatom_port_log(DIATOM_LOG_WARN, "overlay larger than the panel; ignored");
		return;
	}
	if ((size_t)w * (size_t)h > g_ov_under_cap) {
		uint32_t *u = realloc(g_ov_under, (size_t)w * (size_t)h * sizeof *u);

		/* Without it the notice still draws, by reading the page back -
		 * slowly, which is the cost this buffer exists to avoid. */
		if (u) { g_ov_under = u; g_ov_under_cap = (size_t)w * (size_t)h; }
	}
	g_ov = bgra;
	g_ov_w = w;
	g_ov_h = h;
	g_ov_until = diatom_port_now_us() + (uint64_t)ms * 1000ull;
}

/* Straight into the page after the blit and before publish, riding the same
 * flip as the picture - the level bar's arrangement, for the level bar's
 * reason: a second present would be a second presenter. */
static void draw_overlay(uint8_t *base)
{
	const unsigned ro = g_vinfo.red.offset, go = g_vinfo.green.offset;
	const unsigned bo = g_vinfo.blue.offset;
	const int x0 = ov_x0();
	const int y0 = ov_y0();
	int y, x;

	if (!g_ov || y0 < 0 || x0 < 0) return;

	for (y = 0; y < g_ov_h; y++) {
		uint32_t *row = (uint32_t *)(base + (size_t)(y0 + y) * g_finfo.line_length);
		const uint8_t *src = g_ov + (size_t)y * (size_t)g_ov_w * 4;
		const uint32_t *under = g_ov_under ? g_ov_under + (size_t)y * (size_t)g_ov_w
		                                   : NULL;

		for (x = 0; x < g_ov_w; x++) {
			const unsigned a = src[x * 4 + 3];
			uint32_t p;
			unsigned r, g, b;

			if (a == 0) continue;
			p = under ? under[x] : row[x0 + x];
			if (a == 255) {
				r = src[x * 4 + 2];
				g = src[x * 4 + 1];
				b = src[x * 4 + 0];
			} else {
				/* Straight alpha, rounded. The source is not premultiplied
				 * because the launcher renders it with SDL, which is not. */
				r = (src[x * 4 + 2] * a + ((p >> ro) & 0xff) * (255 - a) + 127) / 255;
				g = (src[x * 4 + 1] * a + ((p >> go) & 0xff) * (255 - a) + 127) / 255;
				b = (src[x * 4 + 0] * a + ((p >> bo) & 0xff) * (255 - a) + 127) / 255;
			}
			row[x0 + x] = (r << ro) | (g << go) | (b << bo) | g_opaque;
		}
	}
}

/* Where a notice was last drawn on each page, so it can be taken off again.
 *
 * The picture is redrawn every frame; the letterbox bars are not - they are
 * painted once, when the mode changes. So the part of a notice that falls on
 * a bar stays there after it comes down, which Eric saw in integer mode on
 * 2026-09-30: clear_gain_bar's bug, for the notice. Per page, because each of
 * the three carries its own copy, and per rect, because the next notice may
 * be a different size. */
static diatom_rect g_ov_painted[FB_PAGES];

/* Black wherever `r` lies outside the picture. Inside it, the next blit has
 * already redrawn it. Writes only - the page is never read. */
static void clear_overlay(uint8_t *base, diatom_rect r, diatom_rect dst)
{
	int y, x;

	for (y = r.y; y < r.y + r.h; y++) {
		uint32_t *row = (uint32_t *)(base + (size_t)y * g_finfo.line_length);
		bool covered = y >= dst.y && y < dst.y + dst.h;

		for (x = r.x; x < r.x + r.w; x++) {
			if (covered && x >= dst.x && x < dst.x + dst.w) continue;
			row[x] = BG(x, y);
		}
	}
}

/* The notice's part of one page's present: draw it, or take off what an
 * earlier one left. */
static void overlay_page(uint8_t *base, int page, diatom_rect dst)
{
	diatom_rect now = { ov_x0(), ov_y0(), g_ov_w, g_ov_h };
	diatom_rect *was = &g_ov_painted[page];

	if (was->w > 0 && (!g_ov_live || memcmp(was, &now, sizeof now) != 0)) {
		clear_overlay(base, *was, dst);
		was->w = 0;
	}
	if (g_ov_live && now.x >= 0 && now.y >= 0) {
		draw_overlay(base);
		*was = now;
	}
}

/* Wait until the mailbox is empty and no pan is in flight, and report the page
 * left on glass. The flip thread keeps running - callers want quiescence, not
 * teardown.
 *
 * Two callers, for the same underlying reason. A capture must read the page
 * that is actually displayed rather than whichever one the thread last got to,
 * or the same run at the same frame count yields different images. And a
 * handover must leave nothing in flight before another process starts panning
 * the same framebuffer, or the display switches between their page and ours
 * mid-refresh. */
static int flip_drain(void)
{
	int front;

	pthread_mutex_lock(&g_flip_mx);
	while (g_flip_running && (g_pending >= 0 || g_inflight >= 0))
		pthread_cond_wait(&g_flip_idle, &g_flip_mx);
	front = g_front;
	pthread_mutex_unlock(&g_flip_mx);
	return front;
}

static uint8_t *page_base(int page)
{
	return g_fb + (size_t)page * g_vinfo.yres * g_finfo.line_length;
}

static void clear_pages(void);

void diatom_port_present_stop(diatom_park park_mode)
{
	int front, park;
	struct fb_var_screeninfo v;
	bool was_presenting;

	if (!g_fb) return;
	front = flip_drain();

	was_presenting = g_presented;
	g_presented = false;

	/* Nothing presented since the last stop means somebody else has the
	 * display, and parking would TAKE it - which is what happens when a
	 * player quits from the launcher's in-game menu. Diatom paused at MENU,
	 * the launcher has been drawing its menu ever since, and a park here
	 * seized the panel to show a black page for 150ms before the launcher
	 * got it back. Measured: a pan to the park page landing between two of
	 * the launcher's own, with nothing of Diatom's on screen either side.
	 *
	 * Draining still matters - it is cheap and it costs nothing to be sure
	 * the flip thread is idle - but the pan does not happen. */
	if (!was_presenting) return;

	/* Quiescent is necessary and not sufficient.
	 *
	 * The launcher renders into the SAME framebuffer - measured from its side,
	 * the shelf lands in fb0 with every pixel opaque, so there is one buffer
	 * and not two composited layers. This port uses three pages; a launcher
	 * double-buffering through GL uses two, from yoffset 0 upward. Those
	 * overlap. So a handover that stops on page 0 or 1 leaves the panel
	 * scanning out a page the launcher is about to draw its shelf into, and
	 * the result is interleaved bands of game and shelf - which is what the
	 * 240fps capture showed, rather than the single sweeping boundary two
	 * panners would make.
	 *
	 * Park on the TOP page, which a two-page consumer does not reach. This is
	 * a mitigation with a stated assumption, not a guarantee: nothing here can
	 * stop another process rendering into whatever page it likes. What it does
	 * is make the common case - a fresh consumer taking the low pages - safe,
	 * for the cost of one pan.
	 *
	 * The content parked is up to two frames old in a three-page rotation. At
	 * a handover the last frames are a paused or ending game, so that is
	 * imperceptible, and a stale frame for 30ms is a better trade than a torn
	 * one. */
	if (g_pages < 2 || g_fb_fd < 0) return;
	park = g_pages - 1;

	if (park_mode == DIATOM_PARK_BLANK) {
		/* Opaque black, never a memset to zero: a zero alpha byte makes the
		 * pixel invisible on this panel rather than black, which is the trap
		 * documented at g_opaque and cost a day in 2026-08-24. */
		uint32_t *q = (uint32_t *)page_base(park);
		size_t n = (size_t)g_vinfo.yres * g_finfo.line_length / sizeof *q, i;

		for (i = 0; i < n; i++) q[i] = g_opaque;
	} else {
		if (front == park) return;
		memcpy(page_base(park), page_base(front),
		       (size_t)g_vinfo.yres * g_finfo.line_length);
	}

	v = g_vinfo;
	v.yoffset  = (uint32_t)park * v.yres;
	v.activate = FB_ACTIVATE_VBL;
	if (ioctl(g_fb_fd, FBIOPAN_DISPLAY, &v) != 0) {
		diatom_port_log(DIATOM_LOG_WARN, "pan to park page failed");
		return;
	}
	pthread_mutex_lock(&g_flip_mx);
	g_front = park;
	pthread_mutex_unlock(&g_flip_mx);
}


static void *flip_worker(void *arg)
{
	struct fb_var_screeninfo v = g_vinfo;

	pthread_mutex_lock(&g_flip_mx);
	while (!g_flip_stop) {
		int page;

		if (g_pending < 0) {
			pthread_cond_wait(&g_flip_cv, &g_flip_mx);
			continue;
		}
		page = g_pending;
		g_pending  = -1;
		g_inflight = page;
		pthread_mutex_unlock(&g_flip_mx);

		/* Blocks until the address latches at a vsync - the whole reason
		 * this thread exists. */
		v.yoffset  = (uint32_t)page * v.yres;
		v.activate = FB_ACTIVATE_VBL;
		if (ioctl(g_fb_fd, FBIOPAN_DISPLAY, &v) != 0)
			diatom_port_log(DIATOM_LOG_WARN, "pan failed in flip thread");

		pthread_mutex_lock(&g_flip_mx);
		g_front    = page;
		g_inflight = -1;
		pthread_cond_broadcast(&g_flip_idle);
	}
	pthread_mutex_unlock(&g_flip_mx);
	return arg;
}

/* ---------- the audio sink ------------------------------------------------ */

/* What is open now. Empty means the default device; it is also what the host
 * is told, so "" reads as "wherever this device sends sound by default" rather
 * than as a name nobody recognizes. */
static char g_audio_dev[128];

/* Closing an SDL audio device JOINS its audio thread, and that thread can be
 * blocked writing to a sink that has stopped draining. So this call can fail to
 * return, and on 2026-09-05 a stalled A2DP sink did exactly that.
 *
 * The obvious fix - close on a detached thread - was tried and REVERTED the
 * same day. SDL is not safe against opening a device while a close of another
 * is in flight: test/port_test.c fails three ways with it, the first being that
 * the fallback open after a refused device stops working. A frontend that
 * cannot reopen its audio is worse than one that can hang on a dead headset.
 *
 * The hang is also not really here. The frame loop calls SDL_QueueAudio and
 * SDL_GetQueuedAudioSize every frame, and those take the same device lock the
 * audio thread holds while it writes - so a stalled sink stops the loop whether
 * or not anything closes. Fixing that means not letting the write stall, which
 * is the sink question, not the teardown question.
 */
static bool audio_open(const char *name)
{
	SDL_AudioSpec want, have;

	if (g_audio) { SDL_CloseAudioDevice(g_audio); g_audio = 0; }
	if (name && *name) setenv("AUDIODEV", name, 1);
	else               unsetenv("AUDIODEV");

	SDL_memset(&want, 0, sizeof want);
	want.freq     = AUDIO_RATE;
	want.format   = AUDIO_S16SYS;
	want.channels = 2;
	want.samples  = 1024;

	if (SDL_WasInit(SDL_INIT_AUDIO) == 0 && SDL_InitSubSystem(SDL_INIT_AUDIO) != 0)
		return false;
	/* allowed_changes 0: SDL hands back exactly this spec and converts behind
	 * it, so a sink running at another rate never reaches the resampler and
	 * caps.audio_rate stays true across a reopen. */
	g_audio = SDL_OpenAudioDevice(NULL, 0, &want, &have, 0);
	if (!g_audio) return false;
	SDL_PauseAudioDevice(g_audio, 0);
	/* What SDL actually negotiated, not what was asked for. A sink can open
	 * cleanly and then not carry sound, and when that happened on 2026-09-05
	 * there was no way to tell from outside whether SDL had agreed to
	 * something the device could not service. */
	{
		char msg[192];

		snprintf(msg, sizeof msg,
		         "audio: opened %s at %d Hz, %d ch, %d frames/period, %u byte buffer",
		         name && *name ? name : "the default device",
		         have.freq, have.channels, have.samples, have.size);
		diatom_port_log(DIATOM_LOG_INFO, msg);
	}
	return true;
}

bool diatom_port_audio_set(const char *name, char *actual, size_t cap)
{
	const char *want = name ? name : "";
	bool ok;

	/* Already there. A write on the state plane is idempotent, so re-stating
	 * the current device must not close and reopen a working sink: that drops
	 * whatever is queued and costs a fresh A2DP stream setup. Repeated writes
	 * are not hypothetical - a launcher that recomputes its routing on a timer
	 * sends one whenever it thinks the answer might have moved. */
	if (g_audio && !strcmp(want, g_audio_dev)) {
		diatom_port_audio_get(actual, cap);
		return true;
	}

	ok = audio_open(name);

	if (!ok) {
		char msg[192];

		snprintf(msg, sizeof msg, "audio: %s unavailable (%s); using the default",
		         name && *name ? name : "the default device", SDL_GetError());
		diatom_port_log(DIATOM_LOG_WARN, msg);
		/* The default, and if even that will not open, silence - which the
		 * write path already handles. Never a reason to stop. */
		if (audio_open(NULL)) g_audio_dev[0] = '\0';
	} else {
		snprintf(g_audio_dev, sizeof g_audio_dev, "%s", name ? name : "");
	}
	diatom_port_audio_get(actual, cap);
	return ok;
}

/* Not at init: see diatom_port_audio_start in diatom_port.h. NOT fatal when
 * it fails. A port that cannot open a sound device can still put pixels where
 * the device wants them, and silence costs far less than no emulator: the
 * write path drops, and the host configures the session with capacity 0, which
 * turns dynamic rate control off rather than leaving it correcting for a
 * buffer that does not exist. Tried again at the next start, which costs
 * nothing when it fails. */
bool diatom_port_audio_start(void)
{
	if (g_audio) return true;
	if (audio_open(NULL)) {
		g_audio_dev[0] = '\0';
		return true;
	}
	fprintf(stderr, "audio unavailable (%s); continuing without sound\n", SDL_GetError());
	return false;
}

void diatom_port_audio_get(char *out, size_t cap)
{
	if (out && cap) snprintf(out, cap, "%s", g_audio_dev);
}

bool diatom_port_init(diatom_port_caps *out)
{

	g_mixer_fd = open("/dev/snd/controlC0", O_RDWR);
	g_disp_fd  = open("/dev/disp", O_RDWR);
	mixer_defaults();
	jack_open();
	g_input_debug   = getenv("DIATOM_INPUT_DEBUG") != NULL;
	g_present_debug = getenv("DIATOM_PRESENT_DEBUG") != NULL;

	/* No SDL_INIT_VIDEO: presentation does not go through SDL at all, and the
	 * mali video driver would otherwise claim the display. */
	/* Audio is initialised SEPARATELY and is allowed to fail. A subsystem that
	 * will not come up must not take the rest of the port with it - see the
	 * open below for why silence beats refusing to start. Rolled into one
	 * SDL_Init, a missing or busy audio device is indistinguishable from a
	 * missing display and kills both. */
	if (SDL_Init(SDL_INIT_EVENTS) != 0) {
		fprintf(stderr, "SDL_Init: %s\n", SDL_GetError());
		return false;
	}

	g_fb_fd = open("/dev/fb0", O_RDWR);
	if (g_fb_fd < 0) { perror("open /dev/fb0"); return false; }
	if (ioctl(g_fb_fd, FBIOGET_FSCREENINFO, &g_finfo) != 0 ||
	    ioctl(g_fb_fd, FBIOGET_VSCREENINFO, &g_vinfo) != 0) {
		perror("FBIOGET_SCREENINFO");
		return false;
	}
	if (g_vinfo.bits_per_pixel != 32) {
		/* The panel runs 32bpp (measured); anything else means the display
		 * setup changed and this port needs to learn the new format, not
		 * guess at it. */
		fprintf(stderr, "fb0 is %ubpp, port expects 32\n", g_vinfo.bits_per_pixel);
		return false;
	}

	g_pages = (int)(g_finfo.smem_len / ((size_t)g_vinfo.yres * g_finfo.line_length));
	if (g_pages > FB_PAGES) g_pages = FB_PAGES;
	if (g_pages < 1) { fprintf(stderr, "fb0 too small for one page\n"); return false; }

	g_fb_size = (size_t)g_pages * g_vinfo.yres * g_finfo.line_length;
	g_fb = mmap(NULL, g_fb_size, PROT_READ | PROT_WRITE, MAP_SHARED, g_fb_fd, 0);
	if (g_fb == MAP_FAILED) { perror("mmap fb0"); g_fb = NULL; return false; }

	if (g_vinfo.transp.length > 0)
		g_opaque = ((1u << g_vinfo.transp.length) - 1) << g_vinfo.transp.offset;

	/* Opaque black, not memset zero: zero alpha is invisible, see g_opaque. */
	clear_pages();

	/* Start from a known page. The mailbox needs three pages - front, in
	 * flight, drawing; fewer, or a refused pan, means single-buffered
	 * drawing straight to glass: can tear, still works. */
	g_vinfo.yoffset = 0;
	if (ioctl(g_fb_fd, FBIOPAN_DISPLAY, &g_vinfo) != 0 || g_pages < 3) {
		g_pan_broken = true;
		diatom_port_log(DIATOM_LOG_WARN, "fb0 pan or pages unavailable; single-buffered");
	} else if (pthread_create(&g_flip_thread, NULL, flip_worker, NULL) != 0) {
		g_pan_broken = true;
		diatom_port_log(DIATOM_LOG_WARN, "no flip thread; single-buffered");
	} else {
		g_flip_running = true;
	}
	g_front = 0;

	/* No audio here: it opens once the launcher has drawn, or at the first
	 * game; see diatom_port_audio_start. */

	input_open();

	{
		char msg[160];
		snprintf(msg, sizeof msg,
		         "brick: fb %ux%u stride %u, %d page(s), rgba at %u/%u/%u/%u+%u, audio %d Hz, gamepad %s",
		         g_vinfo.xres, g_vinfo.yres, g_finfo.line_length, g_pages,
		         g_vinfo.red.offset, g_vinfo.green.offset, g_vinfo.blue.offset,
		         g_vinfo.transp.offset, g_vinfo.transp.length,
		         AUDIO_RATE, g_pad_fd >= 0 ? "found" : "none");
		diatom_port_log(DIATOM_LOG_INFO, msg);
	}

	out->surface_w           = (int)g_vinfo.xres;
	out->surface_h           = (int)g_vinfo.yres;
	/* What is asked of SDL, which converts behind it, so the rate holds
	 * whatever device opens later; and the buffer is the port's own, open
	 * or not yet (see diatom_port_audio_start). */
	out->audio_rate          = AUDIO_RATE;
	out->audio_buffer_frames = AUDIO_BUFFER_FRAMES;
	out->present_blocks      = false;
	return true;
}

void diatom_port_shutdown(void)
{
	shade_shutdown();
	if (g_flip_running) {
		pthread_mutex_lock(&g_flip_mx);
		g_flip_stop = true;
		pthread_cond_signal(&g_flip_cv);
		pthread_mutex_unlock(&g_flip_mx);
		pthread_join(g_flip_thread, NULL);
	}
	free(g_colmap);
	free(g_rowmap);
	free(g_ov_under);
	g_ov_under = NULL;
	g_ov_under_cap = 0;
	/* Hand the speaker back on, unless somebody is holding it off.
	 *
	 * Muting at level 0 switches HpSpeaker off, and that is device state which
	 * outlives this process. Leaving it off used to strand the device, because
	 * nothing else drove this switch - the launcher drove `digital volume` and
	 * turning the volume up there could not undo it, so the machine simply
	 * appeared to have lost its speaker.
	 *
	 * THAT REASONING EXPIRED on 2026-09-16. TortOS reads a hardware mute
	 * switch and drives this control itself, so the device is no longer
	 * stranded by an off speaker - and handing it back unconditionally
	 * would un-mute a device whose switch is still down, at the exact
	 * moment a game ends and the launcher's shelf comes back.
	 *
	 * The volume LEVEL is still deliberately not restored - that is a user
	 * setting and belongs wherever they left it. */
	if (g_mixer_fd >= 0) {
		long on = !g_muted;
		ctl_io(SPEAKER_CTL, &on, 1);
		close(g_mixer_fd);
		g_mixer_fd = -1;
	}
	/* Brightness is NOT restored: it is a user setting and the launcher
	 * re-applies its own on resume anyway. Unlike the speaker switch, leaving
	 * it strands nothing - the launcher's own control can always move it. */
	if (g_disp_fd >= 0) { close(g_disp_fd); g_disp_fd = -1; }
	if (g_fb)         munmap(g_fb, g_fb_size);
	if (g_fb_fd >= 0) close(g_fb_fd);
	if (g_pad_fd >= 0) close(g_pad_fd);
	if (g_audio)      SDL_CloseAudioDevice(g_audio);
	SDL_Quit();
}

/* One axis of the resampling map.
 *
 * Sharp-bilinear: take the bilinear weight, then steepen the ramp by the scale
 * factor so the blend spans one DESTINATION pixel rather than one source
 * pixel. Interior pixels come out exact and only the pixel straddling a source
 * boundary is mixed, which is why it looks like integer scaling with the
 * unevenness taken out rather than like a blur.
 *
 * At an integer factor the steepened weight lands on 0 or 1 for every pixel,
 * so the output is identical to nearest by construction - the `integer-sharp`
 * preset exists to demonstrate exactly that.
 *
 * Doubles here are free: this runs once per geometry or filter change, and the
 * per-pixel work uses only the integers it produces. */
static diatom_tap *build_map(int src, int dst, diatom_filter filter)
{
	diatom_tap *m;
	double scale;
	int i;

	if (src <= 0 || dst <= 0) return NULL;
	m = malloc((size_t)dst * sizeof *m);
	if (!m) return NULL;
	scale = (double)dst / (double)src;

	for (i = 0; i < dst; i++) {
		double c  = ((double)i + 0.5) / scale - 0.5;   /* source coordinate */
		int    p  = (int)floor(c);
		double fr = c - (double)p;

		fr = (fr - 0.5) * scale + 0.5;
		if (fr < 0.0) fr = 0.0;
		if (fr > 1.0) fr = 1.0;

		/* Clamp at the edges: no pixel outside the source to blend towards. */
		if (p < 0)        { p = 0;       fr = 0.0; }
		if (p >= src - 1) { p = src - 1; fr = 0.0; }

		if (filter == DIATOM_FILTER_NEAREST) {
			if (fr >= 0.5 && p + 1 < src) p++;
			fr = 0.0;
		}

		m[i].idx = p;
		m[i].w   = (int)(fr * 256.0 + 0.5);
		if (m[i].w > 256) m[i].w = 256;
	}

	/* Collapse a map whose every weight is 0 or 256 onto the fast path. At a
	 * whole factor sharp-bilinear is a no-op by construction, and this makes it
	 * a no-op in cost too: measured, sharp on an integer rect was paying 2.4 ms
	 * a frame to compute the same pixels. */
	for (i = 0; i < dst; i++)
		if (m[i].w != 0 && m[i].w != 256) return m;
	for (i = 0; i < dst; i++)
		if (m[i].w == 256) { m[i].idx++; m[i].w = 0; }
	return m;
}

static bool ensure_maps(int src_w, int src_h, diatom_rect dst,
                        diatom_filter filter)
{
	if (g_map_valid && src_w == g_map_src_w && src_h == g_map_src_h &&
	    filter == g_map_filter && !memcmp(&dst, &g_map_dst, sizeof dst))
		return true;

	free(g_colmap);
	free(g_rowmap);
	g_colmap = build_map(src_w, dst.w, filter);
	g_rowmap = build_map(src_h, dst.h, filter);
	g_map_valid = g_colmap && g_rowmap;
	if (!g_map_valid) return false;

	g_map_src_w = src_w;
	g_map_src_h = src_h;
	g_map_dst   = dst;
	g_map_filter = filter;
	return true;
}

/* Converted source rows, so a source pixel is converted ONCE rather than once
 * per destination pixel that samples it.
 *
 * Measured 2026-08-25: at 256x224 into 1024x768 the naive loop costs 7.52 ms
 * and this costs 3.37 ms, a 2.23x saving, because 4x horizontal and 3.4x
 * vertical scaling meant roughly thirteen redundant conversions of every source
 * pixel. The same measurement showed framebuffer memory is exactly as fast as
 * ordinary heap - 418 MB/s either way - so the cost was never the write, and
 * the disp2 hardware scaler would have been solving the wrong problem.
 *
 * Two slots because a blended row needs the source row above and below. Rows
 * are looked up by index, so consecutive destination rows sampling the same
 * source row convert nothing at all. */
#define ROWCACHE_MAX 2048     /* widest source in the matrix is 512 (SNES hires) */
static uint32_t g_rc[2][ROWCACHE_MAX];
static int      g_rc_row[2] = { -1, -1 };

static const uint32_t *cache_row(const void *src, size_t pitch, diatom_pixfmt fmt,
                                 int row, int src_w)
{
	const unsigned ro = g_vinfo.red.offset;
	const unsigned go = g_vinfo.green.offset;
	const unsigned bo = g_vinfo.blue.offset;
	const uint32_t opaque = g_opaque;
	uint32_t *dst;
	int slot, x;

	if (g_rc_row[0] == row) return g_rc[0];
	if (g_rc_row[1] == row) return g_rc[1];

	/* Evict the older row. Destination rows advance monotonically, so the
	 * lower index is the one that will not be wanted again. */
	slot = (g_rc_row[0] <= g_rc_row[1]) ? 0 : 1;
	dst  = g_rc[slot];

	if (fmt == DIATOM_PIX_RGB565) {
		const uint16_t *in = (const uint16_t *)((const uint8_t *)src + (size_t)row * pitch);
		for (x = 0; x < src_w; x++) {
			const uint16_t c = in[x];
			const uint32_t r = (c >> 11) & 0x1f, g = (c >> 5) & 0x3f, b = c & 0x1f;
			dst[x] = opaque
			       | (((r << 3) | (r >> 2)) << ro)
			       | (((g << 2) | (g >> 4)) << go)
			       | (((b << 3) | (b >> 2)) << bo);
		}
	} else {
		const uint32_t *in = (const uint32_t *)((const uint8_t *)src + (size_t)row * pitch);
		for (x = 0; x < src_w; x++) {
			const uint32_t c = in[x];
			dst[x] = opaque
			       | (((c >> 16) & 0xff) << ro)
			       | (((c >>  8) & 0xff) << go)
			       | (( c        & 0xff) << bo);
		}
	}
	g_rc_row[slot] = row;
	return dst;
}

static inline diatom_rgb unpack(uint32_t p)
{
	diatom_rgb v;
	v.r = (int)((p >> g_vinfo.red.offset)   & 0xff);
	v.g = (int)((p >> g_vinfo.green.offset) & 0xff);
	v.b = (int)((p >> g_vinfo.blue.offset)  & 0xff);
	return v;
}

static inline diatom_rgb mix(diatom_rgb a, diatom_rgb b, int w)
{
	diatom_rgb v;
	v.r = a.r + (((b.r - a.r) * w) >> 8);
	v.g = a.g + (((b.g - a.g) * w) >> 8);
	v.b = a.b + (((b.b - a.b) * w) >> 8);
	return v;
}

/* One panel row in ordinary memory, for the rows under a notice. */
#define UNDER_ROW_MAX 4096
static uint32_t g_under_row[UNDER_ROW_MAX];

bool diatom_port_bezel(const uint8_t *bgra, int w, int h)
{
	const unsigned ro = g_vinfo.red.offset, go = g_vinfo.green.offset;
	const unsigned bo = g_vinfo.blue.offset;
	const size_t W = g_vinfo.xres, H = g_vinfo.yres;
	bool asked = bgra != NULL;
	size_t i;
	int p;

	g_bz = NULL;
	g_bz_runs_ok = false;
	if (bgra && (w != (int)W || h != (int)H)) {
		diatom_port_log(DIATOM_LOG_WARN, "bezel is not the panel's size; ignored");
		bgra = NULL;
	}
	if (bgra) {
		if (!g_bz_bg) g_bz_bg = malloc(W * H * sizeof *g_bz_bg);
		if (!g_bz_ia) g_bz_ia = malloc(W * H);
		if (!g_bz_row) g_bz_row = malloc((H + 1) * sizeof *g_bz_row);
		if (!g_bz_bg || !g_bz_ia || !g_bz_row) {
			diatom_port_log(DIATOM_LOG_WARN, "bezel: no memory; ignored");
			bgra = NULL;
		}
	}
	if (!bgra) {
		free(g_bz_bg);
		g_bz_bg = NULL;
	} else {
		/* Over black: the colour times its alpha. */
		for (i = 0; i < W * H; i++) {
			const uint8_t *s = bgra + i * 4;
			unsigned a = s[3];
			g_bz_bg[i] = (((s[2] * a + 127) / 255) << ro) | (((s[1] * a + 127) / 255) << go) |
			             (((s[0] * a + 127) / 255) << bo) | g_opaque;
			g_bz_ia[i] = (uint8_t)(255 - a);
		}
		g_bz = bgra;
	}
	/* Every page has the old margins: wipe each as it is next drawn. */
	for (p = 0; p < FB_PAGES; p++) g_page_stale[p] = true;
	diatom_port_log(DIATOM_LOG_INFO, g_bz ? "bezel: on" : "bezel: off");
	return g_bz != NULL || !asked;
}

/* Where the bezel is not clear in each row of the picture, as runs: a frame
 * that overlaps the picture's edges is two short runs a row, not the row. */
static void bezel_runs(diatom_rect dst, int x0, int x1, int y0, int y1)
{
	size_t n = 0;
	int y, x;

	g_bz_any = false;
	for (y = 0; y <= (int)g_vinfo.yres; y++) g_bz_row[y] = 0;
	for (y = 0; y < (int)g_vinfo.yres; y++) {
		g_bz_row[y] = (int)n;
		if (y < y0 || y >= y1) continue;
		for (x = x0; x < x1; ) {
			const uint8_t *ia = g_bz_ia + (size_t)y * g_vinfo.xres;
			int a;

			while (x < x1 && ia[x] == 255) x++;
			if (x >= x1) break;
			a = x;
			while (x < x1 && ia[x] != 255) x++;
			if (n + 2 > g_bz_run_cap) {
				size_t cap = g_bz_run_cap ? g_bz_run_cap * 2 : 4096;
				int *r = realloc(g_bz_run, cap * sizeof *r);
				if (!r) { g_bz_runs_ok = false; return; }
				g_bz_run = r;
				g_bz_run_cap = cap;
			}
			g_bz_run[n++] = a;
			g_bz_run[n++] = x;
			g_bz_any = true;
		}
	}
	g_bz_row[g_vinfo.yres] = (int)n;
	g_bz_dst = dst;
	g_bz_runs_ok = true;
}

/* One band of the shaded picture, in ordinary memory, finished: the overlay
 * laid over it and the rows copied to the page and to the notice's slice of
 * it. Called by each of the shader's threads on its own rows. */
typedef struct {
	uint8_t     *page;
	diatom_rect  dst;
	bool         under;
	int          ux0, uy0, x0, x1;
} bezel_band_job;

static bool bezel_row_has(int y);
static void bezel_row(uint32_t *row, int xoff, int y);

static void bezel_band(void *ctx, int r0, int r1)
{
	const bezel_band_job *j = ctx;
	int r;

	for (r = r0; r < r1; r++) {
		int y = j->dst.y + r;
		uint32_t *ram = g_bz_frame + (size_t)r * j->dst.w;
		uint32_t *row = (uint32_t *)(j->page + (size_t)y * g_finfo.line_length);

		if (bezel_row_has(y)) bezel_row(ram, j->dst.x, y);
		memcpy(row + j->dst.x, ram, (size_t)j->dst.w * sizeof *row);
		if (j->under && y >= j->uy0 && y < j->uy0 + g_ov_h) {
			int a = j->x0 > j->ux0 ? j->x0 : j->ux0;
			int b = j->x1 < j->ux0 + g_ov_w ? j->x1 : j->ux0 + g_ov_w;
			if (b > a)
				memcpy(g_ov_under + (size_t)(y - j->uy0) * (size_t)g_ov_w + (a - j->ux0),
				       ram + (a - j->dst.x), (size_t)(b - a) * sizeof *row);
		}
	}
}

/* Is the bezel to be laid over the picture this frame? Readies its runs.
 *
 * Never, for now: an overlay is drawn around the picture and not over it.
 * Overlays made for other systems cast a shadow or a tint into the game's
 * window, and laying that over every frame cost the Brick enough time to
 * break up the sound; the shader draws its own edge shadow and screen
 * anyway. Margins cost nothing per frame (they are painted once per page).
 * The blend below stays for an overlay that is meant to be over the game, if
 * one is ever offered. */
static bool g_bz_inside = false;

static bool bezel_over(diatom_rect dst, int x0, int x1, int y0, int y1)
{
	if (!g_bz || !g_bz_inside) { g_bz_any = false; return false; }
	if (!g_bz_runs_ok || memcmp(&dst, &g_bz_dst, sizeof dst))
		bezel_runs(dst, x0, x1, y0, y1);
	return g_bz_runs_ok && g_bz_any;
}

static bool bezel_row_has(int y)
{
	return g_bz_row[y + 1] > g_bz_row[y];
}

/* The bezel over one row of the picture in ordinary memory: `row` is indexed
 * by panel x less `xoff`. Out = bezel over black + picture * (255 - alpha),
 * the division by 255 done as (v * 257 + 257) >> 16, exact for these. */
static void bezel_row(uint32_t *row, int xoff, int y)
{
	const unsigned ro = g_vinfo.red.offset, go = g_vinfo.green.offset;
	const unsigned bo = g_vinfo.blue.offset;
	const uint32_t *bg = g_bz_bg + (size_t)y * g_vinfo.xres;
	const uint8_t  *ia = g_bz_ia + (size_t)y * g_vinfo.xres;
	int r, x;

	for (r = g_bz_row[y]; r < g_bz_row[y + 1]; r += 2)
		for (x = g_bz_run[r]; x < g_bz_run[r + 1]; x++) {
			const unsigned k = ia[x];
			uint32_t p, q;

			if (!k) { row[x - xoff] = bg[x]; continue; }
			p = row[x - xoff];
			q = bg[x];
			q += ((((p >> ro) & 0xff) * k * 257 + 257) >> 16) << ro;
			q += ((((p >> go) & 0xff) * k * 257 + 257) >> 16) << go;
			q += ((((p >> bo) & 0xff) * k * 257 + 257) >> 16) << bo;
			row[x - xoff] = q;
		}
}

/* Scale-blit src into the destination rect of one page, converting to the
 * framebuffer's own channel order (offsets read from the driver, not assumed).
 *
 * CLIPS rather than refuses: a fill or overscale mode hands over a rect larger
 * than the panel on purpose, and dropping the frame would be the wrong answer
 * to a deliberate crop. */
static void blit(uint8_t *page, const void *src, int w, int h, size_t pitch,
                 diatom_pixfmt fmt, diatom_rect dst)
{
	const unsigned ro = g_vinfo.red.offset;
	const unsigned go = g_vinfo.green.offset;
	const unsigned bo = g_vinfo.blue.offset;
	const uint32_t opaque = g_opaque;
	int x0, x1, y0, y1, y, uy0 = 0, ux0 = 0;
	bool under;

#define PACK(c) (opaque | ((uint32_t)(c).r << ro) \
                        | ((uint32_t)(c).g << go) \
                        | ((uint32_t)(c).b << bo))

/* Two loops, not one with a branch: the vertical weight is constant across a
 * row, so testing it per pixel would be 1024 redundant branches per row.
 *
 * Both source from the converted row cache, so the nearest path - the default,
 * and every pixel at a whole factor - is a pure indexed copy with no arithmetic
 * at all. */
#define BLIT_ROW_NEAREST() do {                                              \
	int x;                                                                   \
	for (x = x0; x < x1; x++) {                                              \
		diatom_tap tx = g_colmap[x - dst.x];                                 \
		if (!tx.w) out[x] = c0[tx.idx];                                      \
		else       out[x] = PACK(mix(unpack(c0[tx.idx]),                     \
		                             unpack(c0[tx.idx + 1]), tx.w));         \
	}                                                                        \
} while (0)

#define BLIT_ROW_BLEND() do {                                                \
	int x;                                                                   \
	for (x = x0; x < x1; x++) {                                              \
		diatom_tap tx = g_colmap[x - dst.x];                                 \
		diatom_rgb a = unpack(c0[tx.idx]);                                   \
		diatom_rgb b = unpack(c1[tx.idx]);                                   \
		if (tx.w) {                                                          \
			a = mix(a, unpack(c0[tx.idx + 1]), tx.w);                        \
			b = mix(b, unpack(c1[tx.idx + 1]), tx.w);                        \
		}                                                                    \
		out[x] = PACK(mix(a, b, ty.w));                                      \
	}                                                                        \
} while (0)

	if (!g_map_valid || w > ROWCACHE_MAX) {
		static bool said;

		/* Once. A source wider than the row cache draws NOTHING, and doing
		 * that sixty times a second in silence is how a blank or stale panel
		 * gets blamed on the core. */
		if (!said) {
			char m[96];

			said = true;
			snprintf(m, sizeof m, "blit refused: source %d wide, cache holds %d",
			         w, ROWCACHE_MAX);
			diatom_port_log(DIATOM_LOG_WARN, m);
		}
		return;
	}

	y0 = dst.y > 0 ? dst.y : 0;
	x0 = dst.x > 0 ? dst.x : 0;
	y1 = dst.y + dst.h < (int)g_vinfo.yres ? dst.y + dst.h : (int)g_vinfo.yres;
	x1 = dst.x + dst.w < (int)g_vinfo.xres ? dst.x + dst.w : (int)g_vinfo.xres;
	if (x1 <= x0 || y1 <= y0) return;

	/* The cache is per-frame: the source buffer is rewritten every time. */
	g_rc_row[0] = g_rc_row[1] = -1;

	/* Under a notice, keep what is drawn: see g_ov_under. Black where the
	 * picture does not reach, as the page is there. */
	under = g_ov_live && g_ov_under && g_ov && ov_x0() >= 0 && ov_y0() >= 0 &&
	        (int)g_vinfo.xres <= UNDER_ROW_MAX;
	if (under) {
		size_t i, n = (size_t)g_ov_w * (size_t)g_ov_h;

		uy0 = ov_y0();
		ux0 = ov_x0();
		if (g_bz_bg)
			for (i = 0; i < n; i++)
				g_ov_under[i] = BG(ux0 + (int)(i % (size_t)g_ov_w), uy0 + (int)(i / (size_t)g_ov_w));
		else
			for (i = 0; i < n; i++) g_ov_under[i] = opaque;
	}

	/* Shaded (ChaOS): at any size with the picture wholly on the panel, the
	 * shader draws the rect itself, in place of the rows below.
	 * Anything else, or a shader that declines, falls through to them. */
	if (dst.x >= 0 && dst.y >= 0 && dst.x + dst.w <= (int)g_vinfo.xres &&
	    dst.y + dst.h <= (int)g_vinfo.yres && dst.w > 0 && dst.h > 0 && shade_active() &&
	    bezel_over(dst, x0, x1, y0, y1)) {
		/* With the bezel over the picture: shaded into ordinary memory, the
		 * bezel laid over it there, and the rows copied to the page and to
		 * the notice's slice of it. Never a read of the page. */
		size_t need = (size_t)dst.w * (size_t)dst.h;

		if (need > g_bz_frame_cap) {
			uint32_t *f = realloc(g_bz_frame, need * sizeof *f);
			if (f) { g_bz_frame = f; g_bz_frame_cap = need; }
		}
		if (need <= g_bz_frame_cap) {
			bezel_band_job job = { page, dst, under, ux0, uy0, x0, x1 };

			/* Each of the shader's threads finishes its own band. */
			shade_band_hook(bezel_band, &job);
			if (shade_frame(src, w, h, pitch, fmt, dst.w, dst.h, g_bz_frame, (size_t)dst.w,
			                ro, go, bo, opaque))
				return;
		}
	}
	if (dst.x >= 0 && dst.y >= 0 && dst.x + dst.w <= (int)g_vinfo.xres &&
	    dst.y + dst.h <= (int)g_vinfo.yres && dst.w > 0 && dst.h > 0 && !(g_bz && g_bz_any) &&
	    shade_frame(src, w, h, pitch, fmt, dst.w, dst.h,
	                (uint32_t *)(page + (size_t)dst.y * g_finfo.line_length) + dst.x,
	                g_finfo.line_length / sizeof(uint32_t), ro, go, bo, opaque)) {
		/* What a notice will need to put back, read from the page: the
		 * shader writes straight to it, with no row in ordinary memory to
		 * copy from as below. A few rows, while a notice shows. */
		if (under) {
			int ya = y0 > uy0 ? y0 : uy0, yb = y1 < uy0 + g_ov_h ? y1 : uy0 + g_ov_h;
			int a = x0 > ux0 ? x0 : ux0, b = x1 < ux0 + g_ov_w ? x1 : ux0 + g_ov_w;
			for (y = ya; y < yb && b > a; y++)
				memcpy(g_ov_under + (size_t)(y - uy0) * (size_t)g_ov_w + (a - ux0),
				       (uint32_t *)(page + (size_t)y * g_finfo.line_length) + a,
				       (size_t)(b - a) * sizeof(uint32_t));
		}
		return;
	}

	bezel_over(dst, x0, x1, y0, y1);
	for (y = y0; y < y1; y++) {
		diatom_tap ty = g_rowmap[y - dst.y];
		uint32_t *row = (uint32_t *)(page + (size_t)y * g_finfo.line_length);
		bool band = under && y >= uy0 && y < uy0 + g_ov_h;
		bool bz = g_bz && g_bz_inside && g_bz_runs_ok && bezel_row_has(y) &&
		          (int)g_vinfo.xres <= UNDER_ROW_MAX;
		uint32_t *out = band || bz ? g_under_row : row;
		const uint32_t *c0 = cache_row(src, pitch, fmt, ty.idx, w);
		const uint32_t *c1 = ty.w ? cache_row(src, pitch, fmt, ty.idx + 1, w) : NULL;

		if (ty.w) BLIT_ROW_BLEND();
		else      BLIT_ROW_NEAREST();
		if (bz) {
			bezel_row(g_under_row, 0, y);
			if (!band) memcpy(row + x0, g_under_row + x0, (size_t)(x1 - x0) * sizeof *row);
		}

		/* Drawn in ordinary memory, then copied to the page and to the
		 * notice's slice of it - two writes, and never a read of the page. */
		if (band) {
			int a = x0 > ux0 ? x0 : ux0;
			int b = x1 < ux0 + g_ov_w ? x1 : ux0 + g_ov_w;

			memcpy(row + x0, g_under_row + x0, (size_t)(x1 - x0) * sizeof *row);
			if (b > a)
				memcpy(g_ov_under + (size_t)(y - uy0) * (size_t)g_ov_w + (a - ux0),
				       g_under_row + a, (size_t)(b - a) * sizeof *row);
		}
	}

	/* Letterbox bars are not repainted per frame: pages start opaque black and
	 * the rect only shrinks when the user changes mode, which clears them. */
#undef BLIT_ROW_NEAREST
#undef BLIT_ROW_BLEND
#undef PACK
}

/* Wipe every page to opaque black. Needed when the rect shrinks, or the
 * previous mode's picture stays framing the new one. */
static void fill_page(uint8_t *base)
{
	size_t y, x;

	for (y = 0; y < g_vinfo.yres; y++) {
		uint32_t *row = (uint32_t *)(base + y * g_finfo.line_length);
		if (g_bz_bg)
			memcpy(row, g_bz_bg + y * g_vinfo.xres, g_vinfo.xres * sizeof *row);
		else
			for (x = 0; x < g_finfo.line_length / sizeof *row; x++) row[x] = g_opaque;
	}
}

static void clear_pages(void)
{
	uint32_t *p = (uint32_t *)g_fb;
	size_t n = g_fb_size / sizeof *p, i;
	int pg;

	if (g_bz_bg) {
		for (pg = 0; pg < g_pages; pg++) fill_page(page_base(pg));
		return;
	}
	for (i = 0; i < n; i++) p[i] = g_opaque;
}

/* Wipe a page the launcher may have drawn into, before drawing a frame into
 * it: see g_page_stale. What was painted on it is gone with it. */
static void wipe_if_stale(int page)
{
	uint32_t *q;
	size_t n, i;

	if (page < 0 || page >= FB_PAGES || !g_page_stale[page]) return;
	q = (uint32_t *)page_base(page);
	n = (size_t)g_vinfo.yres * g_finfo.line_length / sizeof *q;
	if (g_bz_bg) fill_page((uint8_t *)q);
	else for (i = 0; i < n; i++) q[i] = g_opaque;
	g_osd_painted[page] = false;
	g_dot_painted[page] = false;
	memset(&g_ov_painted[page], 0, sizeof g_ov_painted[page]);
	g_page_stale[page] = false;
}

void diatom_port_present(const void *src, int w, int h, size_t pitch,
                         diatom_pixfmt fmt, diatom_rect dst,
                         diatom_filter filter)
{
	uint64_t t0 = 0, t1 = 0;
	bool rect_changed;
	int page;

	/* Dupe frame: the front page already shows it. Nothing to draw, nothing
	 * to flip. */
	if (!src || w <= 0 || h <= 0) return;

	rect_changed = !g_map_valid || memcmp(&dst, &g_map_dst, sizeof dst) != 0;

	/* What the PORT was handed, which is not the same claim as what the host
	 * computed and logged. A game came up filling only the left half of the
	 * panel while the host's own line said 1024x768 at 0,0, and there was no
	 * way to tell which of the two was wrong. Only on a change, so it is one
	 * line per mode rather than one per frame.
	 *
	 * The SOURCE side counts as a change too, and used to not.
	 *
	 * ensure_maps rebuilds on src w/h and filter as well as dst, so a core that
	 * alters its geometry mid-run - which they do, and the host counts them -
	 * silently threw the maps away and built new ones with nothing written
	 * down. That is precisely the case this line exists for: the half-panel
	 * picture, and a report of a GBA game drawn twice side by side while the
	 * display mode was being cycled. Whatever that turns out to be, the log now
	 * says what the port was handed at the moment it changed, including the
	 * pitch - a stride that disagrees with the width is what draws an image
	 * twice across a row. */
	if (rect_changed || w != g_map_src_w || h != g_map_src_h ||
	    filter != g_map_filter) {
		char m[192];

		size_t bpp  = (fmt == DIATOM_PIX_RGB565) ? 2 : 4;
		size_t span = pitch / (bpp ? bpp : 1);

		/* The stride in PIXELS beside the width in pixels. A core is entitled
		 * to pad - mGBA hands over 240 visible pixels in a 256-wide buffer, so
		 * pitch 512 against width 240 is correct and normal, and calling that
		 * a mismatch cries wolf on every GBA frame. What is not survivable is
		 * a stride SHORTER than the width: that reads the next row's pixels
		 * into this one, which is what draws an image twice across a row. */
		snprintf(m, sizeof m,
		         "present: src %dx%d pitch %zu (%zu px) fmt %d -> dst %dx%d "
		         "at %d,%d (panel %ux%u)%s",
		         w, h, pitch, span, (int)fmt, dst.w, dst.h, dst.x, dst.y,
		         g_vinfo.xres, g_vinfo.yres,
		         span >= (size_t)w ? "" : "  <-- STRIDE SHORTER THAN WIDTH");
		diatom_port_log(DIATOM_LOG_INFO, m);
	}

	if (!ensure_maps(w, h, dst, filter)) {
		/* Silent until now: a failed map means present draws nothing at all
		 * and the panel holds whatever was there, which looks like the game
		 * having frozen rather than like an allocation having failed. */
		diatom_port_log(DIATOM_LOG_WARN, "present: no scale map; frame dropped");
		return;
	}
	/* A smaller rect leaves the old picture around the new one. Only on a mode
	 * change, so the cost of wiping every page does not matter. */
	if (rect_changed) {
		clear_pages();
		memset(g_osd_painted, 0, sizeof g_osd_painted);
		memset(g_dot_painted, 0, sizeof g_dot_painted);
		memset(g_ov_painted, 0, sizeof g_ov_painted);
	}

	g_ov_live = g_ov && diatom_port_now_us() < g_ov_until;

	/* The first frame after a handover: every page may hold the launcher's
	 * drawing. */
	if (!g_presented) {
		int p;
		for (p = 0; p < FB_PAGES; p++) g_page_stale[p] = true;
	}

	if (g_pan_broken) {
		wipe_if_stale(g_front);
		blit(page_base(g_front), src, w, h, pitch, fmt, dst);
		if (diatom_port_now_us() < g_osd_until) {
			draw_gain_bar(page_base(g_front));
			g_osd_painted[g_front] = true;
		} else if (g_osd_painted[g_front]) {
			clear_gain_bar(page_base(g_front), dst);
			g_osd_painted[g_front] = false;
		}
		{
			bool dot = dot_visible();

			if (dot || g_dot_painted[g_front]) {
				dot_page(page_base(g_front), dst, dot);
				g_dot_painted[g_front] = dot;
			}
		}
		overlay_page(page_base(g_front), g_front, dst);
		return;
	}

	/* Pick a page holding no role. If every page is spoken for - the panel is
	 * consuming slower than the core produces - steal the pending one: the
	 * thread has not started panning it, so overwriting it just replaces a
	 * frame nobody saw with a newer one. Latest wins. */
	pthread_mutex_lock(&g_flip_mx);
	for (page = 0; page < g_pages; page++)
		if (page != g_front && page != g_inflight && page != g_pending)
			break;
	if (page == g_pages) {
		page      = g_pending;
		g_pending = -1;
	}
	pthread_mutex_unlock(&g_flip_mx);

	if (g_present_debug) t0 = diatom_port_now_us();

	wipe_if_stale(page);

	blit(page_base(page), src, w, h, pitch, fmt, dst);
	/* Painted, or unpainted. A page keeps whatever was last written outside
	 * dst, so the bar has to be taken off the same page it was put on - and
	 * only here, where this page is the one being prepared and no one is
	 * scanning it out. */
	if (diatom_port_now_us() < g_osd_until) {
		draw_gain_bar(page_base(page));
		g_osd_painted[page] = true;
	} else if (g_osd_painted[page]) {
		clear_gain_bar(page_base(page), dst);
		g_osd_painted[page] = false;
	}
	/* The disc the same way: painted every frame it is shown, taken off the
	 * page it was on once it isn't - which, blinking, is every other second. */
	{
		bool dot = dot_visible();

		if (dot || g_dot_painted[page]) {
			dot_page(page_base(page), dst, dot);
			g_dot_painted[page] = dot;
		}
	}
	overlay_page(page_base(page), page, dst);

	pthread_mutex_lock(&g_flip_mx);
	g_presented = true;
	g_pending = page;
	pthread_cond_signal(&g_flip_cv);
	pthread_mutex_unlock(&g_flip_mx);

	if (g_present_debug) {
		static int n;
		t1 = diatom_port_now_us();
		if (++n >= 60) {
			char msg[96];
			n = 0;
			snprintf(msg, sizeof msg, "present: blit+publish %llu us",
			         (unsigned long long)(t1 - t0));
			diatom_port_log(DIATOM_LOG_DEBUG, msg);
		}
	}
}

size_t diatom_port_audio_write(const int16_t *frames, size_t n)
{
	size_t queued, room;

	/* Never blocks; drops on overflow. A blocking write would pace the whole
	 * program off the audio clock, which rules out dynamic rate control.
	 *
	 * Take only what fits. The previous test was `queued >= capacity`, which
	 * refuses only an ALREADY FULL queue and then admits a whole batch: at 4095
	 * queued a 832-frame batch landed entire, and the queue reached a measured
	 * **4927 against a stated 4096**. That mattered beyond the extra latency,
	 * because rate control clamps its error term at +1.0 - reached at exactly
	 * capacity - so everything above capacity was invisible to the controller
	 * that was supposed to be preventing it.
	 *
	 * Clamping rather than refusing the batch outright loses less: the frames
	 * that do not fit are dropped either way, and there is no reason to discard
	 * the ones that would have. */
	/* A sink can die under the port - a headset switched off, or carried out
	 * of range. SDL reports the device STOPPED; falling back happens here
	 * rather than in a poll of its own because this already runs every frame,
	 * and the host finds out through diatom_port_audio_get, which is the only
	 * way it can (the port cannot announce anything).
	 *
	 * Only when a name was asked for. If the DEFAULT device dies there is
	 * nowhere better to go, and retrying it every frame would be a reopen
	 * storm in place of silence. */
	if (g_audio && g_audio_dev[0] &&
	    SDL_GetAudioDeviceStatus(g_audio) == SDL_AUDIO_STOPPED) {
		diatom_port_log(DIATOM_LOG_WARN,
		                "audio: the sink went away; falling back to the default");
		g_audio_dev[0] = '\0';
		audio_open(NULL);
	}
	if (!g_audio || !frames || !n) return 0;
	queued = diatom_port_audio_queued();
	room   = queued >= (size_t)AUDIO_BUFFER_FRAMES
	       ? 0 : (size_t)AUDIO_BUFFER_FRAMES - queued;
	if (n > room) n = room;
	if (!n) return 0;

	SDL_QueueAudio(g_audio, frames, (Uint32)(n * AUDIO_FRAME_BYTES));
	return n;
}

size_t diatom_port_audio_queued(void)
{
	if (!g_audio) return 0;
	return SDL_GetQueuedAudioSize(g_audio) / AUDIO_FRAME_BYTES;
}

/* Kernel code -> Diatom button. brick-pad sends the GKD Pixel 2's codes, so
 * this is the Pixel's table: the caps marked A, B, X, Y send SOUTH, EAST,
 * NORTH, WEST, named for their labels, which puts the right-hand button on the
 * game's A as on a SNES pad; L2 and R2 are keys, the d-pad four keys. MENU is
 * the Brick's own (BTN_MODE). */
static const struct { int code; int btn; } keymap[] = {
	{ BTN_DPAD_UP,    DIATOM_BTN_UP },    { BTN_DPAD_DOWN,  DIATOM_BTN_DOWN },
	{ BTN_DPAD_LEFT,  DIATOM_BTN_LEFT },  { BTN_DPAD_RIGHT, DIATOM_BTN_RIGHT },
	{ BTN_SOUTH,      DIATOM_BTN_A },     { BTN_EAST,       DIATOM_BTN_B },
	{ BTN_NORTH,      DIATOM_BTN_X },     { BTN_WEST,       DIATOM_BTN_Y },
	{ BTN_TL,         DIATOM_BTN_L1 },    { BTN_TR,         DIATOM_BTN_R1 },
	{ BTN_TL2,        DIATOM_BTN_L2 },    { BTN_TR2,        DIATOM_BTN_R2 },
	{ BTN_SELECT,     DIATOM_BTN_SELECT },{ BTN_START,      DIATOM_BTN_START },
	{ BTN_MODE,       DIATOM_BTN_MENU },
};

/* The four level buttons, as level keys: volume on its own two, brightness on
 * the two front keys (BTN_THUMBL and BTN_THUMBR), all on the gamepad. Never
 * reported as buttons, so no brightness press reaches a core. A press is
 * latched until the host has read it, so a tap between two frames counts; a
 * key the events say is held is checked against the kernel, so a release this
 * port never saw cannot leave the host repeating. The stepping and the repeat
 * are the host's. */
static const struct { int code; uint32_t key; } level_buttons[] = {
	{ KEY_VOLUMEUP,   DIATOM_LEVEL_KEY_VOLUME_UP },
	{ KEY_VOLUMEDOWN, DIATOM_LEVEL_KEY_VOLUME_DOWN },
	{ BTN_THUMBR,     DIATOM_LEVEL_KEY_BRIGHTNESS_UP },
	{ BTN_THUMBL,     DIATOM_LEVEL_KEY_BRIGHTNESS_DOWN },
};
#define LEVEL_BUTTONS (sizeof level_buttons / sizeof level_buttons[0])
static uint32_t g_level_down;      /* held, by the events */
static uint32_t g_level_pressed;   /* went down since the host last asked */

/* Whether `code` is a level button, recorded here if so. */
static bool level_button(int code, bool down)
{
	size_t k;

	for (k = 0; k < LEVEL_BUTTONS; k++) {
		if (level_buttons[k].code != code) continue;
		if (down) {
			g_level_down    |= level_buttons[k].key;
			g_level_pressed |= level_buttons[k].key;
		} else {
			g_level_down &= ~level_buttons[k].key;
		}
		return true;
	}
	return false;
}

/* The pad's keys as they are right now, for a start or after the kernel
 * dropped events (SYN_DROPPED): the held-at-entry rule needs to know about a
 * key that was already down. */
static void pad_resync(void)
{
	unsigned long keys[NLONGS(KEY_MAX)];
	size_t i;

	if (g_pad_fd < 0) return;
	memset(keys, 0, sizeof keys);
	if (ioctl(g_pad_fd, EVIOCGKEY(sizeof keys), keys) < 0) return;
	g_buttons = 0;
	for (i = 0; i < sizeof keymap / sizeof keymap[0]; i++)
		if (BIT_IS_SET(keys, keymap[i].code))
			g_buttons |= DIATOM_BIT(keymap[i].btn);
}

/* Normally found already, by jack_open's scan, which runs first. */
static void input_open(void)
{
	if (g_pad_fd < 0) input_scan();
	if (g_pad_fd < 0)
		diatom_port_log(DIATOM_LOG_WARN, "brick: no gamepad found; no game input");
	pad_resync();
}

void diatom_port_input_poll(void)
{
	struct input_event ev[32];
	SDL_Event sev;
	ssize_t n;
	size_t i, k;

	/* The jack, checked once a frame here for the same reason the launcher
	 * checks it in plat_input_poll: whoever is pumping input owns the level,
	 * and this stops being called the moment the game ends. */
	gain_jack_poll();

	while (SDL_PollEvent(&sev))
		if (sev.type == SDL_QUIT) g_quit = true;

	while (g_pad_fd >= 0 && (n = read(g_pad_fd, ev, sizeof ev)) > 0) {
		for (i = 0; i < (size_t)n / sizeof ev[0]; i++) {
			if (ev[i].type == EV_SYN && ev[i].code == SYN_DROPPED) {
				pad_resync();
				continue;
			}
			if (ev[i].type != EV_KEY || ev[i].value == 2) continue;
			if (g_input_debug) {
				char msg[48];
				snprintf(msg, sizeof msg, "key %d -> %d", ev[i].code, ev[i].value);
				diatom_port_log(DIATOM_LOG_DEBUG, msg);
			}
			/* Volume and brightness are the port's, and stop here: during
			 * a game nothing else sees them, the device UI not running. */
			if (level_button(ev[i].code, ev[i].value != 0)) continue;
			for (k = 0; k < sizeof keymap / sizeof keymap[0]; k++) {
				if (keymap[k].code != ev[i].code) continue;
				if (ev[i].value) g_buttons |=  DIATOM_BIT(keymap[k].btn);
				else             g_buttons &= ~DIATOM_BIT(keymap[k].btn);
			}
		}
	}
}

uint32_t diatom_port_input_state(void) { return g_buttons; }

void diatom_port_input_reset(void)
{
	struct input_event ev[32];

	SDL_PumpEvents();
	SDL_FlushEvents(SDL_FIRSTEVENT, SDL_LASTEVENT);
	while (g_pad_fd >= 0 && read(g_pad_fd, ev, sizeof ev) > 0) { }
	g_level_down = g_level_pressed = 0;
	pad_resync();
}

/* ---------- levels: the hardware under them --------------------------------- */

void diatom_port_level_invalidate(void)
{
	g_level = -1;
	/* And the jack, for the reason in the header: a transition that happened
	 * while the launcher was driving is invisible here, so the remembered
	 * state is a memory of a world this process was not watching. */
	g_jack_was = -1;
}

/* The launcher's ladder, when it is not the usual one: 21 positions, or 29 in
 * night mode. Anything else is refused and rescaled as before. */
bool diatom_port_level_scale(diatom_level_kind kind, int positions)
{
	int top = positions - 1;

	if (kind != DIATOM_LEVEL_VOLUME || g_mixer_fd < 0) return false;
	if (top < GAIN_LEVELS || top > GAIN_LEVELS + GAIN_NIGHT_EXTRA) return false;
	g_gain_levels = top;
	g_osd_max     = top;
	return true;
}

/* Positions, not a maximum index, so one MORE than the internal level ceiling.
 * That off-by-one is the whole reason the state plane pins the word. */
int diatom_port_level_positions(diatom_level_kind kind)
{
	switch (kind) {
	case DIATOM_LEVEL_VOLUME:     return g_mixer_fd >= 0 ? g_gain_levels + 1 : 0;
	case DIATOM_LEVEL_BRIGHTNESS: return g_disp_fd >= 0 ? BRIGHT_LEVELS + 1 : 0;
	default:                      return 0;
	}
}

int diatom_port_level_read(diatom_level_kind kind)
{
	long v;

	switch (kind) {
	case DIATOM_LEVEL_VOLUME:
		/* Kept as well as returned: the mute and the jack re-apply act on
		 * the level the hardware is at, read here the first frame after a
		 * handover, before any press writes one. */
		if (gain_io(&v, 0) < 0) return -1;
		g_level = raw_to_level((int)v);
		return g_level;
	case DIATOM_LEVEL_BRIGHTNESS:
		return bright_read();
	default:
		return -1;
	}
}

void diatom_port_level_write(diatom_level_kind kind, int pos)
{
	switch (kind) {
	case DIATOM_LEVEL_VOLUME:
		if (g_mixer_fd < 0) return;
		g_level = pos;
		gain_apply();
		break;
	case DIATOM_LEVEL_BRIGHTNESS:
		if (g_disp_fd < 0) return;
		bright_apply(pos);
		break;
	default:
		break;
	}
}

uint32_t diatom_port_level_keys(void)
{
	unsigned long keys[NLONGS(KEY_MAX)];
	uint32_t out;
	size_t k;

	if (g_level_down) {
		memset(keys, 0, sizeof keys);
		if (g_pad_fd < 0 || ioctl(g_pad_fd, EVIOCGKEY(sizeof keys), keys) < 0)
			memset(keys, 0, sizeof keys);
		for (k = 0; k < LEVEL_BUTTONS; k++)
			if ((g_level_down & level_buttons[k].key) &&
			    !BIT_IS_SET(keys, level_buttons[k].code))
				g_level_down &= ~level_buttons[k].key;
	}
	out = g_level_down | g_level_pressed;
	g_level_pressed = 0;
	return out;
}

void diatom_port_level_shown(diatom_level_kind kind, int pos, int positions)
{
	osd_show(kind == DIATOM_LEVEL_BRIGHTNESS ? 1 : 0, pos, positions - 1);
}
bool     diatom_port_should_quit(void) { return g_quit; }

bool diatom_port_capture(const char *path)
{
	SDL_Surface *s, *rgb;
	bool ok;

	int front;

	if (!g_fb || !path) return false;

	/* Wait for the mailbox to drain before reading the front page.
	 *
	 * Without this, a capture reads whichever page the flip thread last got to,
	 * which depends on how long the blit took - so the same run captured at the
	 * same frame count could yield the frame before. Found 2026-08-25 while
	 * checking a blit optimization for correctness: old and new binaries
	 * produced captures differing in one 24-row band, and only at some frame
	 * counts, which is a blinking sprite one frame apart rather than a blit
	 * defect. An instrument that is not deterministic cannot verify anything. */
	front = flip_drain();

	/* Read back the page on glass. Masks come from the driver's reported
	 * channel offsets, same as the blit writes. */
	s = SDL_CreateRGBSurfaceFrom(page_base(front),
	                             (int)g_vinfo.xres, (int)g_vinfo.yres, 32,
	                             (int)g_finfo.line_length,
	                             0xffu << g_vinfo.red.offset,
	                             0xffu << g_vinfo.green.offset,
	                             0xffu << g_vinfo.blue.offset, 0);
	if (!s) return false;

	/* Plain 24-bit RGB: a 32-bit BMP carries a V4/V5 header several readers
	 * refuse, and the alpha channel is meaningless here anyway. */
	rgb = SDL_ConvertSurfaceFormat(s, SDL_PIXELFORMAT_RGB24, 0);
	SDL_FreeSurface(s);
	if (!rgb) return false;
	ok = SDL_SaveBMP(rgb, path) == 0;
	SDL_FreeSurface(rgb);
	return ok;
}

uint64_t diatom_port_now_us(void)
{
	return diatom_ticks_to_us(SDL_GetPerformanceCounter(),
	                          SDL_GetPerformanceFrequency());
}

void diatom_port_log(diatom_log_level lvl, const char *msg)
{
	static const char *tag[] = { "debug", "info", "warn", "error" };
	fprintf(stderr, "[%s] %s\n", tag[lvl], msg);
}

void diatom_port_mute_set(bool on)
{
	if (on == g_muted) return;
	g_muted = on;
	/* Straight away rather than at the next level change: the whole point is
	 * that a player flipping a switch hears it now. gain_apply writes the
	 * gain too, which is now part of the cut.
	 *
	 * Not with no level, though. Out of a game the level is -1 and the codec
	 * is the launcher's; applying -1 switched the speaker off under it and,
	 * with headphones in, wrote a gain past the register's end that wrapped
	 * around to full volume. Found 2026-09-30. */
	if (g_mixer_fd >= 0 && g_level >= 0) gain_apply();
}

bool diatom_port_mute_get(void) { return g_muted; }

void diatom_port_fast_clock(bool on)
{
	static bool said;

	if (!diatom_cpufreq_hold_top(on, false) && !said) {
		said = true;
		diatom_port_log(DIATOM_LOG_WARN, "brick: could not set the CPU's clock");
	}
}
