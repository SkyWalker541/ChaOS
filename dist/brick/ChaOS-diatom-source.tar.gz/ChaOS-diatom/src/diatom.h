/* Diatom internals.
 *
 * One module organized by file, not by layer. An earlier proposal split "core
 * host" (ABI conformance) from "session" (lifecycle, policy) as separate
 * layers; that seam had one implementation and almost nothing a core asks via
 * RETRO_ENVIRONMENT_* can be answered from ABI knowledge alone. See register §2.
 *
 * The boundary that does matter here is temporal, not architectural:
 * per-game versus per-frame. Everything policy-ish resolves once at load into
 * diatom_policy, which the frame loop reads as plain fields. Cores are
 * permitted to call GET_VARIABLE every frame; a naive implementation would do
 * string comparisons at 60Hz.
 */
#ifndef DIATOM_H
#define DIATOM_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "diatom_port.h"
#include "libretro.h"

/* ---- resolved once at game load; the frame loop only reads ---------------- */
typedef struct {
	const char   *system_dir;
	const char   *save_dir;
	unsigned      controller_type;   /* retro_set_controller_port_device */
	diatom_pixfmt pixfmt;
	bool          pixfmt_set;
	bool          supports_no_game; /* core declared SET_SUPPORT_NO_GAME */
} diatom_policy;

/* ---- a loaded core ------------------------------------------------------- */
typedef struct {
	void       *handle;          /* dlopen'd RTLD_NOW|RTLD_LOCAL */
	const char *path;
	bool        initialized;     /* retro_init has run */
	bool        game_loaded;
	/* What THIS core declared for its frames, kept because it will not say
	 * again. See diatom_env_pixfmt_settle. */
	diatom_pixfmt pixfmt;
	bool          pixfmt_known;

	void   (*set_environment)(retro_environment_t);
	void   (*set_video_refresh)(retro_video_refresh_t);
	void   (*set_audio_sample)(retro_audio_sample_t);
	void   (*set_audio_sample_batch)(retro_audio_sample_batch_t);
	void   (*set_input_poll)(retro_input_poll_t);
	void   (*set_input_state)(retro_input_state_t);
	void   (*set_controller_port_device)(unsigned, unsigned);
	void   (*init)(void);
	void   (*deinit)(void);
	void   (*get_system_info)(struct retro_system_info *);
	void   (*get_system_av_info)(struct retro_system_av_info *);
	bool   (*load_game)(const struct retro_game_info *);
	void   (*unload_game)(void);
	void   (*run)(void);
	void   (*reset)(void);
	size_t (*serialize_size)(void);
	bool   (*serialize)(void *, size_t);
	bool   (*unserialize)(const void *, size_t);
	void  *(*get_memory_data)(unsigned);
	size_t (*get_memory_size)(unsigned);
} diatom_core;

/* zip.c - launcher libraries arrive zipped, one ROM per archive */
bool diatom_zip_is(const char *path);
bool diatom_zip_load(const char *path, void **out, size_t *out_len,
                     char *name, size_t name_n);

/* core.c */
bool diatom_core_open(diatom_core *c, const char *path);
bool diatom_core_start(diatom_core *c, const char *rom_path);
void diatom_core_stop(diatom_core *c);

/* Open once and keep. Returns the same core for the same path, so a repeat
 * launch skips dlopen and retro_init. Never unloaded. Locked, so the premap's
 * thread and a RUN can both call it. */
diatom_core *diatom_core_resident(const char *path);
/* Map every *_libretro.so in `dir`, returning how many are now resident. For
 * the boot path: it costs less than reading them to warm the cache did, and
 * leaves the dynamic linker's work done as well. */
int          diatom_core_premap(const char *dir);

/* env.c */
void diatom_env_bind(diatom_core *c, diatom_policy *p, diatom_port_caps *caps);

/* Bracket a game load so a core that declares its pixel format once, at
 * retro_init, still gets its frames read correctly on every later load.
 * _begin forgets any declaration from the previous game; _settle either
 * records what this core just declared or puts back what it declared the first
 * time. */
void diatom_env_pixfmt_begin(void);
void diatom_env_pixfmt_settle(diatom_core *c);
bool diatom_env_geometry_changed(void);
bool diatom_env_new_geometry(int *w, int *h, double *aspect);   /* consumes the flag */

/* Buttons the host is using for itself this frame and the core must not see.
 * Diatom owns MENU outright (it never appears in the retropad map); this is
 * for keys that are normally the core's but are currently part of a host
 * chord. */
void diatom_env_suppress(uint32_t mask);

/* Silence a core's DEBUG/INFO chatter once a game is running, and log each of
 * its warnings only the first time. See core_log in env.c for the measurements
 * that made this necessary. */
void diatom_env_core_log_quiet(bool quiet);
/* At a game's exit: how many times each warning repeated without being logged. */
void diatom_env_core_log_summary(void);

/* Before each retro_run: whether the frame about to run will be shown, so a
 * core's frameskip can skip drawing one that won't. Whether the running core
 * listens at all is diatom_env_frame_skippable. See env.c. */
void diatom_env_frame_shown(bool shown);
bool diatom_env_frame_skippable(void);

/* options.c - what a core can be configured with, and what it currently is.
 *
 * Diatom holds the definitions and the values; the LAUNCHER decides what the
 * values should be. Diatom has no opinion about whether a Genesis should be PAL
 * and no way to ask, having no UI. */
void        diatom_options_bind(const void *owner);
void        diatom_options_define_v2(const struct retro_core_options_v2 *v2);
void        diatom_options_define_vars(const struct retro_variable *vars);
const char *diatom_options_get(const char *key);
bool        diatom_options_set(const char *key, const char *value);
bool        diatom_options_take_update(void);   /* consumes the flag */
void        diatom_options_list(void);
void        diatom_options_emit(void);   /* over the protocol, for a menu */
/* Drop values the launcher set for a game that is now over - see options.c. */
void        diatom_options_clear_pending(void);

/* proto.c - the launcher protocol. One Unix socket, line-based, tab-separated
 * key=value. Diatom is a component the launcher drives; this is the only place
 * it talks back.
 *
 * The governing rule is about the DISPLAY: ERROR means the game never started,
 * EXIT means it ran and stopped. A launcher that hears RUNNING stops drawing. */
typedef enum {
	DIATOM_MSG_NONE = 0,
	DIATOM_MSG_RUN,
	DIATOM_MSG_STOP,
	DIATOM_MSG_QUIT,
	DIATOM_MSG_PAUSE,      /* open the menu, as a MENU press would */
	DIATOM_MSG_SETIDLE,    /* report idleness after `ms` without input; 0 off */
	DIATOM_MSG_RESUME,     /* leave the menu, Diatom takes the display back */
	DIATOM_MSG_RESET,      /* retro_reset: the menu's Reset row, and nothing else */
	DIATOM_MSG_SAVE,       /* write a state to `path` */
	DIATOM_MSG_LOAD,       /* read a state from `path` */
	DIATOM_MSG_OPTIONS,    /* enumerate this core's options */
	DIATOM_MSG_SETOPT,     /* set `key` to `value` */
	/* The state plane. Each is query / write, and the query verb doubles as
	 * the unsolicited change event so a launcher parses one shape per state
	 * rather than two. */
	DIATOM_MSG_INPUTS,     /* enumerate this game's button labels */
	DIATOM_MSG_MAP,        /* report the active remap table */
	DIATOM_MSG_SETMAP,     /* replace it whole: `map` = "a:b,x:none" */
	DIATOM_MSG_LEVELS,     /* report volume and brightness */
	DIATOM_MSG_SETLEVEL,   /* set `lkind` to `index` of `count` positions */
	DIATOM_MSG_DISPLAY,    /* report the display mode and filter */
	DIATOM_MSG_SETDISPLAY, /* set them: `dmode`, `dfilter` */
	DIATOM_MSG_OVERLAY,    /* composite `path` over the game for `count` ms */
	/* ChaOS. SETSHADER: the launcher's shader settings for the game, from the
	 * file at `path` (shading.c says its form), sent before RUN and again
	 * when they change; with `preview` while paused, the paused frame is
	 * drawn shaded to that BMP and SHADED answers, with the speed check's
	 * figures (shade_ms, busy_ms, frame_ms, measured: main.c's speed_fields).
	 * SETBEZEL: an overlay image
	 * drawn over every frame, from the DTOV file at `path`; empty removes it. */
	/* (ChaOS: MENU+X in a game writes the frame to a BMP and says SHOT
	 * path=; the launcher files it. Diatom-to-launcher, so no message here.) */
	DIATOM_MSG_SETSHADER,
	DIATOM_MSG_SETBEZEL,
	DIATOM_MSG_CHEEVOS,    /* report the achievement set and what has fired */
	DIATOM_MSG_SETCHEEVOS, /* load a set from `path`; empty unloads */
	DIATOM_MSG_AUDIO,      /* report where sound is going */
	DIATOM_MSG_SETAUDIO,   /* send it to `device`; empty means the default */
	DIATOM_MSG_MUTE,       /* report whether the output is being held off */
	DIATOM_MSG_SETMUTE,    /* hold it off, or release it: `on` = 1 | 0 */
	DIATOM_MSG_QUIET,      /* report whether the game's own sound is held silent */
	DIATOM_MSG_SETQUIET,   /* hold it silent, or let it play: `on` = 1 | 0 */
	DIATOM_MSG_SPEED,      /* report the fast-forward step, 1 to 4 */
	DIATOM_MSG_CHANNELS,   /* report which ears hear what */
	DIATOM_MSG_SETCHANNELS,/* set it: `dmode` = stereo | mono | left | right */
	DIATOM_MSG_PREMAP,     /* the launcher has drawn: map the cores now */
	DIATOM_MSG_LOWBATTERY,   /* report whether the low-battery disc is shown */
	DIATOM_MSG_SETLOWBATTERY,/* show it over the game, or not: `on`, `blink` */
	DIATOM_MSG_SETREWIND,  /* ChaOS: keep states to rewind to, `on` = 1 | 0 */
	/* The launcher went away - or was displaced by a newer one, which means
	 * the same thing. The game keeps running. */
	DIATOM_MSG_HANGUP
} diatom_msg_kind;

typedef struct {
	diatom_msg_kind kind;
	char core[1024];
	char rom[1024];
	char firmware[128];    /* RUN: what this content needs in the system dir */
	char tz[64];           /* RUN: the zone a game's clock reads, "" to leave it */
	char tag[64];
	char slot[64];
	/* Session persistence: the launcher passes explicit paths, and these
	 * are how they arrive. All optional. */
	char resume[1024];     /* RUN: state to load at start, if it exists */
	char exit_state[1024]; /* RUN: state written on every way out */
	char preview[1024];    /* RUN: BMP of the frame, on pause and on exit */
	/* Achievements. `console` is a RetroAchievements console id and is not
	 * optional for them: an RA address is an offset into a per-console space,
	 * so 0x06f3 means nothing until the launcher says which console. */
	char cheevos[1024];    /* RUN: a set to watch from the first frame */
	int  console;          /* RUN / SETCHEEVOS */
	char path[1024];       /* SAVE / LOAD / SETCHEEVOS */
	char key[80];          /* SETOPT */
	char value[128];       /* SETOPT */
	char map[512];         /* SETMAP */
	char lkind[32];        /* SETLEVEL: volume | brightness */
	/* SETMUTE and SETQUIET. Both booleans. The mute is a cut measured inaudible
	 * at both ends, so nothing ramps it; quiet is a step in the samples, so
	 * audio.c fades it. */
	int  on;
	int  blink;            /* SETLOWBATTERY: the disc blinks */
	/* SETAUDIO. An output device named the way the PORT names one, passed
	 * straight through: the host's business is which, the port's is how,
	 * and nothing in between reads it. Empty means the default. */
	char device[128];
	char dmode[32];        /* SETDISPLAY: a name from diatom_modes[].
	                        * SETCHANNELS: one from diatom_channels_names[].
	                        * Both arrive as `mode=`, so one slot. */
	char dfilter[16];      /* SETDISPLAY: nearest | sharp */
	int  index, count;     /* SETLEVEL: `count` is POSITIONS, not a max index.
	                        * OVERLAY: `count` is the duration in ms, sent as
	                        * `ms=`. One slot, two verbs, no second name. */
} diatom_msg;

/* Input mapping and labels live in env.c, the one layer a remap touches. */
void diatom_input_reset_map(void);
bool diatom_input_set_map(const char *spec);
void diatom_input_emit_map(void);
void diatom_input_emit_labels(void);

bool diatom_proto_listen(const char *path);
void diatom_proto_close(void);
bool diatom_proto_active(void);
bool diatom_proto_connected(void);
void diatom_proto_send(const char *fmt, ...);

/* timeout_ms < 0 blocks. `running` is reported to a launcher that connects
 * mid-game, so a restarted launcher does not draw over live output. */
diatom_msg_kind diatom_proto_poll(diatom_msg *out, int timeout_ms, bool running);

/* An fd polled alongside the socket, purely so a blocking poll can be woken.
 * Anything readable on it makes the current poll return DIATOM_MSG_NONE, so
 * the caller's loop gets to re-read its own flags; the bytes are drained and
 * discarded, because the fd carries no meaning beyond "look again".
 *
 * A pipe rather than the bare flag, because a signal handler setting a
 * variable does not wake anybody: SIGTERM is process-directed and the kernel
 * may hand it to any thread not blocking it, and Diatom has four - three of
 * them SDL's. A flag set on an SDL thread is a flag nothing reads while the
 * main one sits in poll(-1). The write is what turns the flag into an event.
 *
 * -1 to unregister. */
void diatom_proto_wake_fd(int fd);

/* Async-signal-safe, for the crash handler. `line` must be a complete constant
 * with its own newline: nothing that formats a string is callable from there. */
void diatom_proto_emit_fatal(const char *line);

/* save.c - persistence. Host-side entirely: the port deals in pixels, samples,
 * buttons and time, and a file is none of those.
 *
 * SRAM is automatic because it is the game's own data. Save states are opt-in
 * and take explicit PATHS, never slot numbers - Diatom has no concept of a
 * slot, a game or a system, and the launcher owns all three. */
bool diatom_save_init(diatom_core *c, const char *save_dir, const char *rom_path);
void diatom_save_tick(void);       /* once per frame; may schedule a write */
void diatom_save_flush(void);      /* synchronous; exit and signal paths */
void diatom_save_shutdown(void);
bool diatom_state_save(diatom_core *c, const char *path);
bool diatom_state_load(diatom_core *c, const char *path);

/* scale.c - geometry is arithmetic and lives here, once, so every port agrees.
 * Performing the blit is hardware and belongs to the port.
 *
 * Which mode should be default is OPEN (register §5). The set exists so the
 * question can be answered by looking at a panel rather than by argument. */
typedef enum {
	DIATOM_SCALE_NATIVE,         /* 1x, centered                               */
	DIATOM_SCALE_INTEGER,        /* largest whole factor that fits, boxed     */
	DIATOM_SCALE_INTEGER_VERT,   /* whole factor down, shape-correct across   */
	DIATOM_SCALE_INTEGER_OVER,   /* smallest whole factor that covers, cropped*/
	DIATOM_SCALE_ASPECT_FIT,     /* fractional, shape kept, boxed             */
	DIATOM_SCALE_ASPECT_FILL,    /* fractional, shape kept, cropped           */
	DIATOM_SCALE_STRETCH         /* fills both axes, shape ignored            */
} diatom_scale_mode;

diatom_rect diatom_scale_rect(diatom_scale_mode mode, int src_w, int src_h,
                              double aspect, int surf_w, int surf_h);

/* Mode and filter are independent axes, cycled independently on device. They
 * were briefly modeled as a flat list of (mode, filter) presets on the
 * assumption that most combinations collapse; measurement killed that. FCEUmm
 * reports an 8:7 pixel aspect, about 1.219, not 4:3, so on the Brick's 4:3
 * panel fit, fill and stretch are three different pictures. */
typedef struct {
	const char       *name;
	diatom_scale_mode mode;
	const char       *note;
} diatom_display_mode_info;

extern const diatom_display_mode_info diatom_modes[];
extern const int                      diatom_mode_count;

/* audio.c - cores emit 32040..131072 Hz; the device runs at whatever it runs at.
 * A polyphase windowed sinc, with dynamic rate control holding the port's buffer
 * near half full, because a fixed ratio drifts until the buffer empties or
 * overflows. */
void   diatom_audio_configure(double src_rate, int dst_rate, int capacity_frames);
size_t diatom_audio_push(const int16_t *in, size_t frames);
void   diatom_audio_prime(void);           /* fill to target: frame one, menu */
void   diatom_audio_sync(void);            /* once per frame, after pushing */
double diatom_audio_ratio_drift(void);     /* current DRC correction, for reporting */
/* Frames the port refused, this session. Nonzero means rate control is not
 * keeping up - the buffer is hitting a wall rather than being steered. */
uint64_t diatom_audio_dropped(void);

/* Peak absolute sample, and how many of the samples written were non-zero.
 * The first thing to check when nothing is audible. */
void     diatom_audio_note_input(const int16_t *f, size_t n);
/* Raw S16 stereo taps either side of the resampler, for offline analysis. */
void     diatom_audio_tap(const char *in_path, const char *out_path);
void     diatom_audio_tap_close(void);
int      diatom_audio_in_peak(void);
uint64_t diatom_audio_in_nonzero(void);
uint64_t diatom_audio_in_samples(void);
int      diatom_audio_peak(void);
double   diatom_audio_rms(void);
double   diatom_audio_in_rms(void);
uint64_t diatom_audio_nonzero(void);
uint64_t diatom_audio_samples(void);

/* QUIET: the game's own sound replaced by silence, faded, after the
 * resampler - so the stream, its timing and the device carry on untouched and
 * the port never knows. Held across sessions, because it describes the
 * launcher's situation rather than the game: a session starts at whatever it
 * is set to, with no fade. */
void     diatom_audio_quiet(bool on);
bool     diatom_audio_quiet_get(void);
/* Output frames this session that went out quiet, fades included - so a silent
 * OUT line above can be told from a silent game. */
uint64_t diatom_audio_quiet_frames(void);

/* CHANNELS: which ears hear what, for a player who hears with one. Stereo as
 * the game made it; mono, the two channels as one, in both; left or right,
 * the two as one on that side and silence on the other. The launcher chooses
 * per output - it never asks a speaker for one side - and this does it after
 * the resampler, ramped the way quiet is, so a change never clicks. Held
 * across sessions like quiet: a session starts mixed as asked, with no ramp. */
typedef enum {
	DIATOM_CHANNELS_STEREO = 0,
	DIATOM_CHANNELS_MONO,
	DIATOM_CHANNELS_LEFT,
	DIATOM_CHANNELS_RIGHT,
	DIATOM_CHANNELS_COUNT
} diatom_channels;
extern const char *const diatom_channels_names[DIATOM_CHANNELS_COUNT];
void            diatom_audio_channels(diatom_channels c);
diatom_channels diatom_audio_channels_get(void);

#endif /* DIATOM_H */
