/* Diatom port interface.
 *
 * THIS HEADER MUST NOT INCLUDE libretro.h, AND NEITHER MAY ANY PORT.
 * That is the mechanical test for whether the seam holds: a port that needs a
 * core to build cannot be developed on the desktop, which destroys the
 * iteration loop the desktop backend exists to provide.
 *
 * The port deals in pixels, samples, buttons and time. Nothing else. If a
 * function name here grows a domain noun - game, save, core, menu - it is in
 * the wrong layer.
 *
 * Port selection is compile-time: one binary per device, no plugin mechanism.
 * Nobody swaps a device backend at runtime on a handheld.
 */
#ifndef DIATOM_PORT_H
#define DIATOM_PORT_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* Cores may emit 0RGB1555 too; Diatom refuses it. Measured 2026-08-23: all six
 * cores tested chose RGB565 when offered both. The XRGB8888 path is accepted
 * because it costs nothing, but it is currently untested - see the spike. */
typedef enum {
	DIATOM_PIX_RGB565,
	DIATOM_PIX_XRGB8888
} diatom_pixfmt;

typedef enum {
	DIATOM_LOG_DEBUG,
	DIATOM_LOG_INFO,
	DIATOM_LOG_WARN,
	DIATOM_LOG_ERROR
} diatom_log_level;

/* How to sample when the destination rect is not an exact integer multiple of
 * the source. Choosing is policy (host); sampling is hardware (port), the same
 * split the port interface applies to the rect itself.
 *
 * SHARP is sharp-bilinear: interpolate only across the one destination pixel
 * that straddles a source-pixel boundary, leaving every interior pixel exact.
 * At an integer factor it is identical to NEAREST by construction.
 *
 * Passed per frame rather than set once, so the port holds no policy state and
 * cannot be asked to present before it has been told how. */
typedef enum {
	DIATOM_FILTER_NEAREST,
	DIATOM_FILTER_SHARP
} diatom_filter;

typedef struct { int x, y, w, h; } diatom_rect;

typedef struct {
	/* Logical and ALWAYS landscape. A port whose panel is physically rotated
	 * - the Miniloong's framebuffer is 720x960 portrait - hides that here.
	 * Nothing above the port may learn the panel's true orientation. */
	int  surface_w, surface_h;

	int  audio_rate;            /* what the device actually runs at */
	int  audio_buffer_frames;   /* capacity; DRC needs this, not just queued */
	bool present_blocks;        /* does present() wait for vblank? */
} diatom_port_caps;

/* Canonical Diatom buttons. Digital only, no analog axes anywhere.
 * Bit positions within diatom_port_input_state(). Deliberately NOT libretro's
 * RETRO_DEVICE_ID_JOYPAD_*: the near-identity mapping is what keeps libretro.h
 * out of the port. Device quirks - the Brick reporting its front keys as
 * L3/R3, say - are resolved here and never travel upward. */
enum {
	DIATOM_BTN_UP = 0, DIATOM_BTN_DOWN, DIATOM_BTN_LEFT, DIATOM_BTN_RIGHT,
	DIATOM_BTN_A, DIATOM_BTN_B, DIATOM_BTN_X, DIATOM_BTN_Y,
	DIATOM_BTN_L1, DIATOM_BTN_R1, DIATOM_BTN_L2, DIATOM_BTN_R2,
	DIATOM_BTN_SELECT, DIATOM_BTN_START,
	/* Diatom's own key: never forwarded to a core. The port REPORTS it like
	 * any other button and does not act on it - what MENU means is host
	 * policy, and it differs by mode. Standalone it ends the session; under
	 * the launcher protocol it hands the display over for a menu. A port that
	 * decided this itself would make that impossible. */
	DIATOM_BTN_MENU,
	DIATOM_BTN_COUNT
};
#define DIATOM_BIT(b) (1u << (b))

bool diatom_port_init(diatom_port_caps *out);
void diatom_port_shutdown(void);

/* Called AFTER retro_run returns, never from inside the core's video callback.
 * The host owns `src` and has already computed `dst`; the port blits.
 * src == NULL means "repeat the previous frame" (the core signaled a dupe).
 *
 * `dst` may extend past the surface: a fill or overscale mode deliberately
 * crops. Ports clip; they never refuse the frame.
 *
 * Seven parameters is at the edge of reasonable. If this list grows again it
 * wants a struct, not an eighth argument. */
void diatom_port_present(const void *src, int w, int h, size_t pitch,
                         diatom_pixfmt fmt, diatom_rect dst,
                         diatom_filter filter);

/* An image composited over the presented frame for a while, in SCREEN space -
 * the same job the port already does for its own level bar, which is why it
 * lives here rather than in the host: the OSD is drawn after scaling, and a
 * host that wanted to draw it would have to copy and scale the frame itself.
 *
 * Pixels and a duration. The port is not told what the image means, and it
 * must not care: `overlay` is a pixel word, and a parameter named for an
 * achievement or a message would be this header's own rule being broken.
 *
 * `bgra` is 8-bit BGRA, straight (not premultiplied), `w * 4` bytes per row.
 * THE POINTER IS BORROWED, not copied: the host guarantees it stays valid and
 * unchanged until the next call or until the duration elapses. That keeps the
 * buffer in one place instead of one per port, which matters on a device where
 * a notice is 150KB and the whole process is meant to hold 8MB.
 *
 * ms == 0, or bgra == NULL, clears it. An image larger than the surface is
 * refused rather than clipped: something drawn half off the screen is a bug
 * that looks like a design choice. */
void diatom_port_overlay(const uint8_t *bgra, int w, int h, unsigned ms);

/* A shader to draw frames with, from the next present on (ChaOS).
 *
 * The host chooses (which game gets which shader, and its settings); the port
 * draws, because the shader works in screen space and replaces the port's own
 * scaling. NONE draws frames plainly. PT is SkyWalker541's pixel transparency
 * shader, CRT crt-lottes-fast and LCD lcd3x; `params` are the shader's values
 * in its header's order (shaders/cpu_shader.h names them all); the pointer is
 * read during the call and not kept.
 *
 * A shader draws only at a whole-number scale with the picture wholly on the
 * surface. Any other frame is drawn plainly, so a port may always fall back,
 * and a port that cannot shade at all may ignore this. */
typedef enum {
	DIATOM_SHADER_NONE,
	DIATOM_SHADER_PT,
	DIATOM_SHADER_CRT,
	DIATOM_SHADER_LCD,
	DIATOM_SHADER_SCAN
} diatom_shader;

void diatom_port_shader(diatom_shader kind, const float *params, int nparams);

/* What the shader costs (ChaOS's speed check): the average time it took to
 * draw a frame, in ms, over the frames drawn since it was last set, how many
 * frames that is, and how many threads draw it. A port that draws no shaders
 * says 0 frames. */
void diatom_port_shade_cost(double *ms, unsigned *frames, int *threads);

/* A bezel: an image drawn over every frame, picture and margins alike (ChaOS).
 * Straight-alpha BGRA, w x h, which must be the panel's size; NULL removes it.
 * The pointer is BORROWED until the next call, as diatom_port_overlay's.
 * Returns false when refused (the wrong size, or no memory). */
bool diatom_port_bezel(const uint8_t *bgra, int w, int h);

/* Stop presenting, without tearing down. Returns when nothing is pending and
 * nothing is in flight, so a SECOND presenter may take the display safely.
 * The port stays initialized and must serve the next diatom_port_present.
 *
 * This exists because presenting lifetime and process lifetime came apart.
 * init/shutdown bracket the process and present() is per frame; nothing
 * bracketed one GAME's presenting, which was fine while a frontend ran one
 * game and exited. Then the process became long-lived and the display was
 * handed to the launcher per game, and the seam was never grown to
 * match - so `EXIT` and `PAUSED` were sent while this port was still panning,
 * and for a few milliseconds two processes drove the same framebuffer.
 * Measured from the launcher side as a boundary sweeping down the panel
 * across several frames: a tear, not a composite.
 *
 * `park` says what to LEAVE on glass, because the port cannot know and the
 * answer differs by handover:
 *
 *   KEEP  - the last frame. Right for a pause, where the launcher draws its
 *           menu over the frame the player stopped on and wants continuity.
 *   BLANK - opaque black. Right for an exit, where the launcher's first act
 *           is to fade the shelf up from black, so black is the state it is
 *           about to assume anyway.
 *
 * Getting that backwards is visible. Parking KEEP at exit replaces whatever
 * was on screen - the launcher's own menu, if the player quit from it - with
 * a bare game frame for the few tens of milliseconds before the fade starts,
 * which reads as a flash. It is not a tear: it is the wrong picture, shown
 * cleanly.
 *
 * Not diatom_port_shutdown - that joins the flip thread, and the thread has
 * to survive to serve the next game. */
typedef enum {
	DIATOM_PARK_KEEP,
	DIATOM_PARK_BLANK
} diatom_park;

void diatom_port_present_stop(diatom_park park);

/* Interleaved stereo S16 at caps.audio_rate. NEVER blocks; drops on overflow.
 * A blocking write is a legitimate sync strategy but is incompatible with
 * dynamic rate control, which the measured spread of core rates makes
 * mandatory: 32040 / 32768 / 44100 / 48000 / 65536 Hz across six cores.
 *
 * RETURNS the number of frames accepted, which may be fewer than `n` and may
 * be zero. Returning void made "drops on overflow" unobservable: the host
 * could not tell a dropped frame from a written one, so the only evidence of
 * trouble was the queue depth - and the queue was allowed to exceed the
 * capacity reported in caps, which hid it there too. A port must never accept
 * more than caps.audio_buffer_frames; partial acceptance is how it says no. */
size_t diatom_port_audio_write(const int16_t *frames, size_t n);
size_t diatom_port_audio_queued(void);

/* WHERE the sound goes, named the way this port's audio system names a device -
 * an ALSA device string on the Brick, an SDL device name on the desktop.
 *
 * The host says WHICH, the port knows HOW. The string crosses here
 * exactly as a core path does, and the port never learns what kind of thing it
 * names. "bluetooth" is not a word this interface knows, for the same reason
 * Diatom keeps no core list - which output to use is the host application's
 * decision, and a port that answered it would be holding a device list.
 *
 * NULL or empty is the default device.
 *
 * FALLS BACK rather than failing. A named device that will not open leaves the
 * port on the default and still running, because a sink that can be set while a
 * game runs can fail while a game runs, and ending the game is never the better
 * answer. Returns true when it opened what was asked for and false when it fell
 * back, filling `actual` either way - the host reports where the sound IS, not
 * where it asked for it to be.
 *
 * Reopening does not change caps.audio_rate: the port asks SDL for a fixed rate
 * and lets it convert, so a sink that runs at another rate is the port's problem
 * and never the resampler's. */
bool diatom_port_audio_set(const char *name, char *actual, size_t cap);

/* The default device, opened if nothing is open yet; true when one is open
 * after. A second call changes nothing, so it never throws away what is
 * queued.
 *
 * NOT at init, and that is the point of it. Opened at init, the stream was
 * running before the host had drawn its first frame, and the host's own
 * writes to the codec (on the Brick, its headphone stage and speaker
 * switches) then powered those paths up on the spot, with the driver's waits:
 * 124 ms of the launcher's start, on two boots of three, depending on which
 * process got there first (measured 2026-10-18). Opened after, those writes
 * only record a setting, and the power-up happens here. The host calls this
 * when the launcher has drawn (PREMAP) and at the start of every session,
 * whichever comes first; a device set by diatom_port_audio_set is open
 * already.
 *
 * caps.audio_buffer_frames is the port's buffer, open or not yet. When this
 * fails the host configures the session with 0, as for a port with no
 * sound. */
bool diatom_port_audio_start(void);

/* MUTE, which this port OBEYS rather than owns.
 *
 * The launcher reads a hardware switch and cuts the analog stage, which sits
 * below the mixer and silences every producer at once. Nothing about the pin,
 * the polarity, or what the switch MEANS belongs here.
 *
 * What the port must do is narrow: while this is set, never turn the output
 * back ON. It may still cut the path for its OWN silence - on this codec the
 * gain control's minimum is about -74 dB rather than nothing, so level 0 has
 * to switch the stage off as well - and that stays the port's business.
 *
 * The fault this exists for was demonstrated, not guessed: with the launcher
 * muted and a game running, a volume press brought the sound straight back,
 * because applying a level writes the same control. A port with no such stage
 * implements this as a no-op and is correct. */
void diatom_port_mute_set(bool on);
bool diatom_port_mute_get(void);

/* Where the sound actually is now.
 *
 * Polled, like the level pair below and for the same reason: the port must not
 * know the launcher protocol exists, so it cannot announce anything.
 * A sink that dies under the port - a headset switched off, or walking out of
 * range - is noticed here, because the port falls back on its own and the answer
 * changes. The host reads it beside the input bitfield it already polls. */
void diatom_port_audio_get(char *out, size_t cap);

void     diatom_port_input_poll(void);
uint32_t diatom_port_input_state(void);

/* Called when a pause ends, before the next poll. While paused nothing polls,
 * and the launcher's menu was time somebody spent pressing buttons: a port
 * whose input queues (evdev, SDL's event queue) would read it all back on the
 * next poll and act on it again - a volume key pressed three times in the menu
 * was three more steps on resume, measured on the GKD Pixel 2 2026-10-02. So
 * the queue is thrown away, and what is held is read from the device as it is
 * now. */
void     diatom_port_input_reset(void);

/* Levels the user can change with the device's own keys while a game runs -
 * volume and brightness on the Brick and the GKD Pixel 2, nothing at all on
 * the desktop.
 *
 * The LEVEL is the host's (src/levels.c): which position each is at,
 * stepping it, holding a key to repeat, the shared scale it crosses the socket
 * on. The port is the hardware under it: how many positions a control has on
 * this device, what position the hardware is at, writing one, which level keys
 * are held, and drawing the bar. Raw device units (mixer registers, backlight
 * duty) never leave the port.
 *
 * A position is 0-based over `0 .. positions - 1`, and `positions` is the
 * number of distinct positions rather than a maximum index - the two differ by
 * one, and the state plane pins it because a shared scale that is off by one
 * produces a silent disagreement instead of an error. */
typedef enum {
	DIATOM_LEVEL_VOLUME = 0,
	DIATOM_LEVEL_BRIGHTNESS,
	DIATOM_LEVEL_COUNT
} diatom_level_kind;

/* How many positions this device has for `kind`, or 0 if it has no control
 * over it. */
int  diatom_port_level_positions(diatom_level_kind kind);
/* Adopts a ladder of `positions` rungs when the host sends a count the port
 * can make, so a longer ladder (the launcher's night mode) keeps its steps
 * instead of being squashed into the usual ones. Returns false when the port
 * has no such ladder, and the state plane rescales as before. */
bool diatom_port_level_scale(diatom_level_kind kind, int positions);

/* Where the hardware is now, as a position, or -1 if it cannot be read. A
 * register left outside the port's window by another program reads as the
 * nearer end. */
int  diatom_port_level_read(diatom_level_kind kind);

/* Put the hardware at `pos`. What position 0 means (a cut, on a volume control
 * whose minimum is not silence), the launcher's mute and re-mapping the volume
 * when the headphone jack changes are all the port's: it keeps what it last
 * wrote for that. */
void diatom_port_level_write(diatom_level_kind kind, int pos);

/* The level keys held right now, or pressed since the last call, as
 * DIATOM_LEVEL_KEY_* bits - the second so a tap that goes down and up between
 * two frames still counts. Which physical key is which is the port's: on the
 * GKD Pixel 2 a volume key pressed while MENU is held is a brightness key
 * until it is let go. The host steps on a press and repeats while held; the
 * port only reports. diatom_port_input_reset clears what is latched. */
enum {
	DIATOM_LEVEL_KEY_VOLUME_UP       = 1u << 0,
	DIATOM_LEVEL_KEY_VOLUME_DOWN     = 1u << 1,
	DIATOM_LEVEL_KEY_BRIGHTNESS_UP   = 1u << 2,
	DIATOM_LEVEL_KEY_BRIGHTNESS_DOWN = 1u << 3,
};
uint32_t diatom_port_level_keys(void);

/* Show the level bar for `kind` at `pos` of `positions`, for a moment from now.
 * Drawn by the port, in its own pixels; the host calls this on every step, so
 * a held key keeps it up. */
void diatom_port_level_shown(diatom_level_kind kind, int pos, int positions);

/* Show the low-battery disc over the game, or take it off. The launcher
 * decides what low and critical mean; the port draws the disc the launcher
 * draws on its own screens, in the same place: radius 9, centered 34 px from
 * the top and right edges, red (224, 72, 72), on every frame until told
 * otherwise. `blink` (critical): shown in the even seconds of the port's
 * clock and not in the odd ones, the launcher's rhythm. A port with no screen
 * of its own implements this as a no-op and is correct. */
void diatom_port_low_battery(bool on, bool blink);

/* Hold the CPU at its top clock, or give the clock back to the governor. The
 * host says true while a game runs fast, and false at 1x, in the menu, at the
 * end of a session and once at start, which clears a hold a crashed Diatom
 * left behind. It may say it every turn; the port acts on a change.
 *
 * Fast forward is the one time a game needs the top clock and ondemand does
 * not give it: a fast turn waits out what is left of its periods, so the CPU
 * looks idle enough to be clocked down, and a turn that no longer fits drops
 * the speed by a whole step, not a little. Measured on the Pixel 2,
 * 2026-10-28, a heavy GBA game at 4x for a minute and more: 2.36x with the
 * clock pinned at 1296 MHz, 1.71x pinned at 1008, and 1.48x to 2.17x left to
 * ondemand, which moved between the two. A port with no clock of its own to
 * set implements this as a no-op and is correct. */
void diatom_port_fast_clock(bool on);

/* Forget everything the port remembers about the output state.
 *
 * Needed because Diatom is RESIDENT: the port keeps what it last wrote, to
 * re-apply it on a jack change or a mute, and the launcher owns levels whenever
 * Diatom is not presenting. So between games, and across a menu, the hardware
 * can be changed underneath it, and re-applying a stale write would put back a
 * level nobody is at.
 *
 * That includes the LAST HEADPHONE JACK STATE the port acted on, and forgetting
 * it is not an extra: a port re-maps the level between the speaker and
 * headphone windows on a transition IT observes, and it observes none while the
 * launcher is driving. A cable pulled out between games therefore leaves a
 * headphone-window value in the register that neither side re-maps, because
 * each sees its own remembered state already agreeing with the hardware. On
 * this device that reads as a working speaker at almost no volume. Measured
 * 2026-09-05: the register held 29 with a speaker window whose quiet end is 39.
 *
 * So this is called at every handover (the host forgets its own positions at
 * the same moment), and nothing is re-applied until the next write rather than
 * trusting a memory formed while something else was driving. */
void diatom_port_level_invalidate(void);

/* True once the port's surface has gone away - a closed window on desktop.
 * Not in the original design; surfaced during implementation. It concerns the
 * port's own viability, not anything about games, so it belongs here. */
bool diatom_port_should_quit(void);

/* Write what was last presented. Pixels and a path, no domain nouns, and both
 * backends want it - on desktop to see what happened, on device because a
 * screenshot is otherwise unobtainable. Also not in the original design: it
 * specified ten functions and implementation has made it twelve within a day,
 * which is worth noticing even though both additions look justified. */
bool diatom_port_capture(const char *path);

uint64_t diatom_port_now_us(void);
void     diatom_port_log(diatom_log_level lvl, const char *msg);

#endif /* DIATOM_PORT_H */
